"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Upload, Type, Mic, Cloud, Sparkles, BarChart3, Zap, Stars, Wand2 } from "lucide-react"
import { FileUploader } from "@/components/file-uploader"
import { TextEditor } from "@/components/text-editor"
import { VoiceConverter } from "@/components/voice-converter"
import { CloudIntegration } from "@/components/cloud-integration"
import { AIStoryEnhancement } from "@/components/ai-story-enhancement"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"

export default function EchoVerse() {
  const [inputText, setInputText] = useState("")
  const [enhancedText, setEnhancedText] = useState("")
  const [selectedVoice, setSelectedVoice] = useState("neural-voice-1")
  const [audioUrl, setAudioUrl] = useState("")
  const [chapters, setChapters] = useState<Array<{ title: string; content: string; startTime: number }>>([])
  const [projectTitle, setProjectTitle] = useState("My Audiobook Project")

  const handleEnhancedText = (
    text: string,
    generatedChapters: Array<{ title: string; content: string; startTime: number }>,
  ) => {
    setEnhancedText(text)
    setChapters(generatedChapters)
  }

  const currentText = enhancedText || inputText

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>

        {/* Floating particles */}
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 bg-black/20 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl blur-lg opacity-75 animate-pulse"></div>
                <div className="relative p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
                  EchoVerse
                </h1>
                <p className="text-lg text-gray-300 font-medium">AI-Powered Audiobook Creation Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="px-4 py-2 bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 text-green-300 rounded-full text-sm font-medium backdrop-blur-sm">
                <Stars className="h-4 w-4 inline mr-2" />
                IBM Granite Powered
              </div>
              <div className="px-4 py-2 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-500/30 text-blue-300 rounded-full text-sm font-medium backdrop-blur-sm">
                <Zap className="h-4 w-4 inline mr-2" />
                Cloud Integrated
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Welcome Section */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">
              Transform Your Stories Into{" "}
              <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Captivating Audio
              </span>
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Create professional audiobooks with AI-powered text generation, natural voice synthesis, and seamless
              cloud integration
            </p>
          </div>

          {/* Main Tabs */}
          <Tabs defaultValue="upload" className="space-y-8">
            <div className="flex justify-center">
              <TabsList className="grid grid-cols-6 bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-2 shadow-2xl">
                <TabsTrigger
                  value="upload"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-white/10"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload
                </TabsTrigger>
                <TabsTrigger
                  value="type"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-white/10"
                >
                  <Type className="h-4 w-4 mr-2" />
                  Type
                </TabsTrigger>
                <TabsTrigger
                  value="enhance"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-white/10"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Enhance
                </TabsTrigger>
                <TabsTrigger
                  value="convert"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-white/10"
                >
                  <Mic className="h-4 w-4 mr-2" />
                  Convert
                </TabsTrigger>
                <TabsTrigger
                  value="cloud"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-white/10"
                >
                  <Cloud className="h-4 w-4 mr-2" />
                  Share
                </TabsTrigger>
                <TabsTrigger
                  value="analytics"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-white/10"
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Analytics
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="upload" className="animate-fade-in">
              <FileUploader onTextExtracted={setInputText} />
            </TabsContent>

            <TabsContent value="type" className="animate-fade-in">
              <TextEditor text={inputText} onTextChange={setInputText} />
            </TabsContent>

            <TabsContent value="enhance" className="animate-fade-in">
              <AIStoryEnhancement originalText={inputText} onEnhancedText={handleEnhancedText} />
            </TabsContent>

            <TabsContent value="convert" className="animate-fade-in">
              <VoiceConverter text={currentText} selectedVoice={selectedVoice} onVoiceSelect={setSelectedVoice} />
            </TabsContent>

            <TabsContent value="cloud" className="animate-fade-in">
              <CloudIntegration
                audioUrl={audioUrl || "mock-audio-url"}
                title={projectTitle}
                metadata={{
                  duration: Math.ceil(currentText.split(" ").length / 150) * 60,
                  fileSize: currentText.length * 1024,
                  chapters: chapters.map((ch) => ({ title: ch.title, startTime: ch.startTime })),
                }}
              />
            </TabsContent>

            <TabsContent value="analytics" className="animate-fade-in">
              <AnalyticsDashboard
                audioTitle={projectTitle}
                chapters={chapters.map((ch) => ({
                  title: ch.title,
                  startTime: ch.startTime,
                  duration: Math.ceil(ch.content.split(" ").length / 150) * 60,
                }))}
              />
            </TabsContent>
          </Tabs>

          {/* Current Project Status */}
          {currentText && (
            <Card className="mt-8 bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden animate-slide-up">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10"></div>
              <CardHeader className="relative">
                <CardTitle className="text-2xl font-bold text-white flex items-center space-x-3">
                  <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl">
                    <Wand2 className="h-6 w-6 text-white" />
                  </div>
                  <span>Project Status</span>
                </CardTitle>
                <CardDescription className="text-lg text-gray-300">
                  {currentText.split(" ").length} words • {chapters.length} chapters • Estimated{" "}
                  {Math.ceil(currentText.split(" ").length / 150)} minutes
                </CardDescription>
              </CardHeader>
              <CardContent className="relative">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="group">
                    <div className="text-center p-6 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-2xl border border-blue-500/30 backdrop-blur-sm transition-all duration-300 hover:scale-105 hover:shadow-xl">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-blue-600 rounded-xl mx-auto mb-3 flex items-center justify-center">
                        <Type className="h-6 w-6 text-white" />
                      </div>
                      <p className="text-lg font-semibold text-blue-300">Text Ready</p>
                      <p className="text-sm text-gray-400">✓ Content loaded</p>
                    </div>
                  </div>

                  <div className="group">
                    <div className="text-center p-6 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-2xl border border-yellow-500/30 backdrop-blur-sm transition-all duration-300 hover:scale-105 hover:shadow-xl">
                      <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl mx-auto mb-3 flex items-center justify-center">
                        <Sparkles className="h-6 w-6 text-white" />
                      </div>
                      <p className="text-lg font-semibold text-yellow-300">AI Enhanced</p>
                      <p className="text-sm text-gray-400">{enhancedText ? "✓ Enhanced" : "○ Available"}</p>
                    </div>
                  </div>

                  <div className="group">
                    <div className="text-center p-6 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl border border-green-500/30 backdrop-blur-sm transition-all duration-300 hover:scale-105 hover:shadow-xl">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-emerald-500 rounded-xl mx-auto mb-3 flex items-center justify-center">
                        <Mic className="h-6 w-6 text-white" />
                      </div>
                      <p className="text-lg font-semibold text-green-300">Voice Ready</p>
                      <p className="text-sm text-gray-400">✓ {selectedVoice}</p>
                    </div>
                  </div>

                  <div className="group">
                    <div className="text-center p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl border border-purple-500/30 backdrop-blur-sm transition-all duration-300 hover:scale-105 hover:shadow-xl">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-500 rounded-xl mx-auto mb-3 flex items-center justify-center">
                        <Cloud className="h-6 w-6 text-white" />
                      </div>
                      <p className="text-lg font-semibold text-purple-300">Cloud Ready</p>
                      <p className="text-sm text-gray-400">✓ Export available</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Features Showcase */}
          {!currentText && (
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 animate-fade-in">
              <Card className="bg-black/30 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden hover:scale-105 transition-all duration-300 group">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                    <Sparkles className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">AI Story Enhancement</h3>
                  <p className="text-gray-300">
                    Transform your text with IBM Granite AI for better narrative flow and structure
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden hover:scale-105 transition-all duration-300 group">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                    <Mic className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Natural Voice Synthesis</h3>
                  <p className="text-gray-300">
                    Convert text to lifelike speech with multiple voice options and customization
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden hover:scale-105 transition-all duration-300 group">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl mx-auto mb-6 flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                    <Cloud className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Cloud Integration</h3>
                  <p className="text-gray-300">
                    Share and distribute your audiobooks across multiple platforms seamlessly
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
