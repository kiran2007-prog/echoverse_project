import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt, genre, length } = await request.json()

    // Simulate IBM Granite API integration
    // In production, you would call the actual IBM Granite API here
    const response = await simulateGraniteAPI(prompt, genre, length)

    return NextResponse.json(response)
  } catch (error) {
    console.error("Text generation error:", error)
    return NextResponse.json({ error: "Failed to generate text" }, { status: 500 })
  }
}

async function simulateGraniteAPI(prompt: string, genre: string, length: string) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 2000))

  const storyTemplates = {
    fantasy: `Chapter 1: The Awakening

In the mystical realm of ${generateRandomName()}, where ancient magic flows through crystalline rivers and whispers through enchanted forests, a young ${generateRandomRole()} named ${generateRandomName()} discovered their extraordinary gift.

The morning sun cast golden rays through the chamber window, illuminating the leather-bound tome that would change their destiny forever. As they opened the ancient book, the pages began to glow with an ethereal light, revealing secrets that had been hidden for centuries.

"The time has come," whispered a voice that seemed to emanate from the very walls. "Your journey begins now, young one. The fate of all realms rests in your hands."

Chapter 2: The Quest Begins

The cobblestone streets of the village below bustled with activity as our hero made their way to the town square. Merchants hawked their wares, children played in the fountain, and the aroma of fresh bread wafted from the bakery.

At the center of the square stood an ancient oak tree, its branches reaching toward the sky like gnarled fingers. Carved into its trunk were symbols that seemed to pulse with magical energy, and as they approached, the symbols began to glow.`,

    scifi: `Chapter 1: First Contact

The year was 2387, and humanity had just made contact with an alien civilization from the ${generateRandomName()} system. Commander ${generateRandomName()} stood on the bridge of the starship Endeavor, watching as the massive alien vessel approached through the void of space.

"Sir, we're receiving a transmission," reported the communications officer, her voice tense with anticipation.

The viewscreen flickered to life, revealing a being unlike anything they had ever seen. Its crystalline features seemed to shift and change in the light, and when it spoke, its voice resonated with harmonics that seemed to touch the very soul.

Chapter 2: The Message

"Greetings, children of Earth," the alien entity began, its words translated by the ship's advanced AI systems. "We have traveled far to bring you a warning. A great darkness approaches your galaxy, and only together can we hope to stand against it."

The bridge fell silent as the implications of the message sank in. This was not just first contact—it was a call to arms.`,

    mystery: `Chapter 1: The Disappearance

Detective ${generateRandomName()} had seen many strange cases in their twenty years on the force, but nothing quite like this. The entire family had vanished without a trace, leaving behind only a cryptic note and a room that defied all logical explanation.

The note, written in elegant handwriting, simply read: "The truth lies where shadows dance with light." But it was the room itself that truly puzzled the detective—every surface was covered in intricate symbols that seemed to shift when viewed from different angles.

Chapter 2: Following the Clues

As the investigation deepened, more questions arose than answers. Witnesses reported seeing strange lights in the sky the night of the disappearance, and several neighbors mentioned hearing what sounded like ancient chanting coming from the house.

The detective's partner, Officer ${generateRandomName()}, discovered that the symbols matched those found in an archaeological dig from the previous year—a dig that had been mysteriously shut down by government officials.`,
  }

  const baseStory = storyTemplates[genre as keyof typeof storyTemplates] || storyTemplates.fantasy

  // Extend story based on length
  let finalStory = baseStory
  if (length === "medium") {
    finalStory += `\n\nChapter 3: Deeper Mysteries\n\nAs the story unfolds, our protagonist discovers that their initial understanding was only the beginning. New allies emerge from unexpected places, and the true scope of their challenge becomes clear.\n\nChapter 4: The Turning Point\n\nA crucial revelation changes everything, forcing difficult choices and testing the bonds of friendship and loyalty.`
  } else if (length === "long") {
    finalStory += `\n\nChapter 3: Deeper Mysteries\n\nAs the story unfolds, our protagonist discovers that their initial understanding was only the beginning. New allies emerge from unexpected places, and the true scope of their challenge becomes clear.\n\nChapter 4: The Turning Point\n\nA crucial revelation changes everything, forcing difficult choices and testing the bonds of friendship and loyalty.\n\nChapter 5: Rising Action\n\nThe stakes continue to rise as our hero faces increasingly difficult challenges, each one testing their resolve and pushing them to their limits.\n\nChapter 6: The Climax\n\nIn a dramatic confrontation, all the threads of the story come together in an epic battle between good and evil, light and darkness.\n\nChapter 7: Resolution\n\nThe dust settles, and our hero must come to terms with the consequences of their actions and the changes they have undergone throughout their journey.`
  }

  return {
    success: true,
    text: finalStory,
    metadata: {
      genre,
      length,
      wordCount: finalStory.split(" ").length,
      estimatedDuration: Math.ceil(finalStory.split(" ").length / 150), // 150 words per minute
    },
  }
}

function generateRandomName(): string {
  const names = [
    "Aria",
    "Zephyr",
    "Luna",
    "Orion",
    "Nova",
    "Phoenix",
    "Sage",
    "River",
    "Storm",
    "Ember",
    "Raven",
    "Atlas",
    "Iris",
    "Jasper",
    "Celeste",
    "Kai",
  ]
  return names[Math.floor(Math.random() * names.length)]
}

function generateRandomRole(): string {
  const roles = [
    "apprentice",
    "scholar",
    "wanderer",
    "guardian",
    "seeker",
    "keeper",
    "warrior",
    "mage",
    "healer",
    "explorer",
    "inventor",
    "diplomat",
  ]
  return roles[Math.floor(Math.random() * roles.length)]
}
