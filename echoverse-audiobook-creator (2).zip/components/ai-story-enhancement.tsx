"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Sparkles, BookOpen, Zap, CheckCircle, RefreshCw, FileText, Layers } from "lucide-react"

interface AIStoryEnhancementProps {
  originalText: string
  onEnhancedText: (text: string, chapters: Array<{ title: string; content: string; startTime: number }>) => void
}

export function AIStoryEnhancement({ originalText, onEnhancedText }: AIStoryEnhancementProps) {
  const [enhancedText, setEnhancedText] = useState("")
  const [chapters, setChapters] = useState<Array<{ title: string; content: string; startTime: number }>>([])
  const [isEnhancing, setIsEnhancing] = useState(false)
  const [enhancementProgress, setEnhancementProgress] = useState(0)
  const [enhancementType, setEnhancementType] = useState<"narrative" | "dialogue" | "structure" | "complete">(
    "complete",
  )

  const enhancementOptions = [
    {
      id: "narrative",
      name: "Narrative Enhancement",
      description: "Improve storytelling flow and descriptions",
      icon: BookOpen,
      color: "bg-blue-500",
    },
    {
      id: "dialogue",
      name: "Dialogue Polish",
      description: "Enhance character conversations",
      icon: FileText,
      color: "bg-green-500",
    },
    {
      id: "structure",
      name: "Structure Optimization",
      description: "Organize chapters and pacing",
      icon: Layers,
      color: "bg-purple-500",
    },
    {
      id: "complete",
      name: "Complete Enhancement",
      description: "Full AI rewrite and optimization",
      icon: Sparkles,
      color: "bg-gradient-to-r from-purple-500 to-blue-500",
    },
  ]

  const enhanceStory = async () => {
    if (!originalText.trim()) {
      alert("Please provide text to enhance!")
      return
    }

    setIsEnhancing(true)
    setEnhancementProgress(0)

    try {
      // Simulate AI enhancement process
      const steps = [
        "Analyzing text structure...",
        "Identifying narrative elements...",
        "Enhancing storytelling flow...",
        "Improving dialogue quality...",
        "Optimizing chapter structure...",
        "Generating enhanced content...",
        "Finalizing improvements...",
      ]

      for (let i = 0; i < steps.length; i++) {
        setEnhancementProgress(((i + 1) / steps.length) * 100)
        await new Promise((resolve) => setTimeout(resolve, 1000))
      }

      // Simulate IBM Granite enhancement
      const enhanced = await simulateAIEnhancement(originalText, enhancementType)
      setEnhancedText(enhanced.text)
      setChapters(enhanced.chapters)

      onEnhancedText(enhanced.text, enhanced.chapters)
    } catch (error) {
      console.error("Enhancement error:", error)
      alert("Enhancement failed. Please try again.")
    } finally {
      setIsEnhancing(false)
    }
  }

  const simulateAIEnhancement = async (text: string, type: string) => {
    // Simulate IBM Granite API enhancement
    const words = text.split(" ")
    const wordCount = words.length

    let enhancedText = ""
    let chapters: Array<{ title: string; content: string; startTime: number }> = []

    if (type === "complete") {
      // Complete rewrite with better narrative structure
      enhancedText = `Enhanced Introduction

${text}

The narrative has been enhanced with improved flow, richer descriptions, and better character development. The AI has restructured sentences for optimal audio delivery, added transitional phrases for smoother listening, and enhanced dialogue to sound more natural when spoken aloud.

Enhanced Conclusion

This enhanced version maintains the original story's essence while optimizing it for audiobook format. The pacing has been adjusted for better listener engagement, and descriptive elements have been enriched to create a more immersive audio experience.`

      // Auto-generate chapters
      const sections = enhancedText.split("\n\n").filter((section) => section.trim().length > 0)
      let currentTime = 0

      chapters = sections.map((section, index) => {
        const sectionWords = section.split(" ").length
        const duration = (sectionWords / 150) * 60 // 150 words per minute

        const chapter = {
          title: index === 0 ? "Introduction" : index === sections.length - 1 ? "Conclusion" : `Chapter ${index}`,
          content: section,
          startTime: currentTime,
        }

        currentTime += duration
        return chapter
      })
    } else {
      // Specific enhancement types
      enhancedText = `[${type.toUpperCase()} ENHANCED]\n\n${text}\n\n[Enhancement applied: ${type}]`

      // Simple chapter detection
      const paragraphs = text.split("\n\n")
      let currentTime = 0

      chapters = paragraphs.map((paragraph, index) => {
        const words = paragraph.split(" ").length
        const duration = (words / 150) * 60

        const chapter = {
          title: `Section ${index + 1}`,
          content: paragraph,
          startTime: currentTime,
        }

        currentTime += duration
        return chapter
      })
    }

    return { text: enhancedText, chapters }
  }

  const getEnhancementStats = () => {
    if (!enhancedText) return null

    const originalWords = originalText.split(" ").length
    const enhancedWords = enhancedText.split(" ").length
    const improvement = (((enhancedWords - originalWords) / originalWords) * 100).toFixed(1)

    return {
      originalWords,
      enhancedWords,
      improvement: Number.parseFloat(improvement),
      chapters: chapters.length,
      estimatedDuration: Math.ceil(enhancedWords / 150),
    }
  }

  const stats = getEnhancementStats()

  return (
    <div className="space-y-6">
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-yellow-400" />
            <span>AI Story Enhancement</span>
          </CardTitle>
          <CardDescription className="text-gray-300">
            Use IBM Granite AI to improve narrative quality and structure your text for better audiobook experience
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Enhancement Options */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {enhancementOptions.map((option) => {
              const Icon = option.icon
              return (
                <Card
                  key={option.id}
                  className={`cursor-pointer transition-all ${
                    enhancementType === option.id
                      ? "bg-purple-600/30 border-purple-500"
                      : "bg-black/20 border-white/10 hover:bg-white/5"
                  }`}
                  onClick={() => setEnhancementType(option.id as any)}
                >
                  <CardContent className="p-3 text-center">
                    <div className={`p-2 ${option.color} rounded-lg mx-auto mb-2 w-fit`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <h4 className="font-semibold text-white text-xs">{option.name}</h4>
                    <p className="text-xs text-gray-400 mt-1">{option.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Enhancement Progress */}
          {isEnhancing && (
            <div className="space-y-2">
              <Progress value={enhancementProgress} className="h-2" />
              <p className="text-sm text-gray-400 text-center">
                Enhancing with IBM Granite AI... {Math.round(enhancementProgress)}%
              </p>
            </div>
          )}

          {/* Enhancement Button */}
          <Button
            onClick={enhanceStory}
            disabled={isEnhancing || !originalText.trim()}
            className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
          >
            {isEnhancing ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Enhancing Story...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Enhance with AI
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Enhancement Results */}
      {stats && (
        <Card className="bg-green-500/20 border-green-500/30 text-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span>Enhancement Complete</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-400">{stats.enhancedWords}</p>
                <p className="text-xs text-gray-300">Enhanced Words</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-400">+{stats.improvement}%</p>
                <p className="text-xs text-gray-300">Content Increase</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-400">{stats.chapters}</p>
                <p className="text-xs text-gray-300">Auto Chapters</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-400">{stats.estimatedDuration}m</p>
                <p className="text-xs text-gray-300">Est. Duration</p>
              </div>
            </div>

            {/* Enhanced Text Preview */}
            <div>
              <h4 className="font-semibold text-white mb-2">Enhanced Text Preview:</h4>
              <Textarea
                value={enhancedText}
                onChange={(e) => setEnhancedText(e.target.value)}
                className="bg-black/20 border-white/20 text-white min-h-[200px]"
              />
            </div>

            {/* Chapter Structure */}
            <div>
              <h4 className="font-semibold text-white mb-2">Auto-Generated Chapters:</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {chapters.map((chapter, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-black/20 rounded">
                    <span className="text-sm font-medium">{chapter.title}</span>
                    <Badge variant="secondary" className="text-xs">
                      {Math.floor(chapter.startTime / 60)}:{(chapter.startTime % 60).toFixed(0).padStart(2, "0")}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
