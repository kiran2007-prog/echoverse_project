"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { AudioWaveformIcon as Waveform, RefreshCw, CheckCircle } from "lucide-react"

interface AudioProcessorProps {
  text: string
  voice: string
  onAudioGenerated: (url: string) => void
  isProcessing: boolean
  setIsProcessing: (processing: boolean) => void
}

export function AudioProcessor({ text, voice, onAudioGenerated, isProcessing, setIsProcessing }: AudioProcessorProps) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState("")
  const [audioGenerated, setAudioGenerated] = useState(false)

  const handleGenerateAudio = async () => {
    if (!text) return

    setIsProcessing(true)
    setProgress(0)
    setAudioGenerated(false)

    const steps = [
      "Analyzing text structure...",
      "Processing with IBM Granite...",
      "Generating speech synthesis...",
      "Applying voice effects...",
      "Optimizing audio quality...",
      "Finalizing audiobook...",
    ]

    for (let i = 0; i < steps.length; i++) {
      setCurrentStep(steps[i])
      setProgress((i + 1) * (100 / steps.length))
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }

    // Simulate audio generation
    const mockAudioUrl = "/placeholder.svg?height=100&width=400"
    onAudioGenerated(mockAudioUrl)
    setAudioGenerated(true)
    setIsProcessing(false)
    setCurrentStep("Audio generation complete!")
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Waveform className="h-5 w-5 text-green-400" />
            <span>Audio Processing</span>
          </CardTitle>
          <CardDescription className="text-gray-300">
            Convert your text to high-quality audiobook format
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-blue-500/20 rounded-lg border border-blue-500/30">
              <h4 className="font-semibold text-blue-300 mb-1">Text Length</h4>
              <p className="text-2xl font-bold text-white">{text.split(" ").length}</p>
              <p className="text-sm text-gray-300">words</p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg border border-purple-500/30">
              <h4 className="font-semibold text-purple-300 mb-1">Est. Duration</h4>
              <p className="text-2xl font-bold text-white">{Math.ceil(text.split(" ").length / 150)}</p>
              <p className="text-sm text-gray-300">minutes</p>
            </div>
          </div>

          {isProcessing && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">{currentStep}</span>
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-300">
                  Processing
                </Badge>
              </div>
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-gray-400 text-center">{Math.round(progress)}% complete</p>
            </div>
          )}

          {audioGenerated && (
            <div className="p-4 bg-green-500/20 rounded-lg border border-green-500/30">
              <div className="flex items-center space-x-2 mb-2">
                <CheckCircle className="h-5 w-5 text-green-400" />
                <h4 className="font-semibold text-green-300">Audio Generated Successfully!</h4>
              </div>
              <p className="text-sm text-gray-300">Your audiobook is ready for preview and download.</p>
            </div>
          )}

          <Button
            onClick={handleGenerateAudio}
            disabled={!text || isProcessing}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
          >
            {isProcessing ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Waveform className="h-4 w-4 mr-2" />}
            {isProcessing ? "Generating Audio..." : "Generate Audiobook"}
          </Button>
        </CardContent>
      </Card>

      {/* Audio Enhancement Options */}
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-lg">Enhancement Options</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
              <h4 className="font-medium text-white mb-1">Noise Reduction</h4>
              <p className="text-xs text-gray-400">Remove background noise</p>
            </div>
            <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
              <h4 className="font-medium text-white mb-1">Audio Normalization</h4>
              <p className="text-xs text-gray-400">Consistent volume levels</p>
            </div>
            <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
              <h4 className="font-medium text-white mb-1">Chapter Markers</h4>
              <p className="text-xs text-gray-400">Auto-detect chapters</p>
            </div>
            <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
              <h4 className="font-medium text-white mb-1">Quality Boost</h4>
              <p className="text-xs text-gray-400">AI-enhanced clarity</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
