"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Type, RotateCcw, Sparkles, BookOpen, Feather } from "lucide-react"

interface TextEditorProps {
  text: string
  onTextChange: (text: string) => void
}

export function TextEditor({ text, onTextChange }: TextEditorProps) {
  const handleClear = () => {
    onTextChange("")
  }

  const wordCount = text.split(" ").filter((word) => word.length > 0).length
  const charCount = text.length
  const estimatedMinutes = Math.ceil(wordCount / 150)

  return (
    <div className="space-y-8">
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 via-transparent to-blue-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-3 bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl">
              <Type className="h-6 w-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Write Your Story
            </span>
          </CardTitle>
          <CardDescription className="text-lg text-gray-300">
            Type or paste your text here. Watch the magic happen as your words come to life.
          </CardDescription>
        </CardHeader>
        <CardContent className="relative space-y-6">
          <div className="relative">
            <Textarea
              value={text}
              onChange={(e) => onTextChange(e.target.value)}
              placeholder="Once upon a time, in a world where words could dance and stories could sing..."
              className="bg-black/20 backdrop-blur-sm border-white/30 text-white placeholder:text-gray-400 min-h-[400px] resize-none rounded-2xl text-lg leading-relaxed focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 transition-all duration-300"
            />
            {text && (
              <div className="absolute top-4 right-4">
                <div className="p-2 bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm rounded-xl border border-white/20">
                  <Feather className="h-4 w-4 text-purple-400" />
                </div>
              </div>
            )}
          </div>

          {/* Stats Bar */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-2xl border border-white/10 backdrop-blur-sm">
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{wordCount}</p>
                <p className="text-sm text-gray-400">words</p>
              </div>
              <div className="w-px h-8 bg-white/20"></div>
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{charCount}</p>
                <p className="text-sm text-gray-400">characters</p>
              </div>
              <div className="w-px h-8 bg-white/20"></div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-400">{estimatedMinutes}</p>
                <p className="text-sm text-gray-400">min audio</p>
              </div>
            </div>

            <Button
              onClick={handleClear}
              variant="outline"
              size="sm"
              className="border-white/30 text-white hover:bg-white/10 bg-transparent rounded-xl transition-all duration-300 hover:scale-105"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Clear
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Examples */}
      <Card className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-2xl">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <h4 className="font-semibold text-white text-lg">Quick Start Examples</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              variant="outline"
              className="border-white/20 text-white hover:bg-gradient-to-r hover:from-purple-500/20 hover:to-blue-500/20 bg-transparent text-left justify-start p-6 h-auto rounded-2xl transition-all duration-300 hover:scale-105 hover:border-purple-400/50"
              onClick={() =>
                onTextChange(
                  "Welcome to EchoVerse! This is an AI-powered text-to-speech converter that can transform any written content into natural-sounding audio using advanced voice synthesis technology. Experience the future of audiobook creation with our cutting-edge platform that combines artificial intelligence with intuitive design.",
                )
              }
            >
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4 text-blue-400" />
                  <span className="font-semibold">Sample Introduction</span>
                </div>
                <p className="text-sm text-gray-400">Professional introduction text</p>
              </div>
            </Button>

            <Button
              variant="outline"
              className="border-white/20 text-white hover:bg-gradient-to-r hover:from-purple-500/20 hover:to-blue-500/20 bg-transparent text-left justify-start p-6 h-auto rounded-2xl transition-all duration-300 hover:scale-105 hover:border-purple-400/50"
              onClick={() =>
                onTextChange(
                  "Once upon a time, in a land far beyond the misty mountains and shimmering seas, there lived a young inventor named Luna who dreamed of creating machines that could help people communicate across great distances. Her workshop was filled with gears, crystals, and mysterious contraptions that hummed with magical energy.",
                )
              }
            >
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Sparkles className="h-4 w-4 text-purple-400" />
                  <span className="font-semibold">Fantasy Story</span>
                </div>
                <p className="text-sm text-gray-400">Magical story beginning</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
