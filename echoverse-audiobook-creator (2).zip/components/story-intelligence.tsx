"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Brain, Sparkles, Heart, Users, TrendingUp, Lightbulb, Target } from "lucide-react"

interface StoryIntelligenceProps {
  text: string
  onAnalysisComplete: (analysis: StoryAnalysis) => void
}

interface StoryAnalysis {
  emotionalTone: {
    primary: string
    secondary: string
    intensity: number
    timeline: Array<{ chapter: string; emotion: string; intensity: number }>
  }
  characters: Array<{
    name: string
    personality: string
    voiceSuggestion: string
    emotionalArc: string
  }>
  pacing: {
    overall: string
    recommendations: string[]
    optimalBreaks: number[]
  }
  audienceAnalysis: {
    targetAge: string
    complexity: number
    engagement: number
    recommendations: string[]
  }
  voiceRecommendations: Array<{
    character: string
    voice: string
    reasoning: string
    emotionalRange: string[]
  }>
}

export function StoryIntelligence({ text, onAnalysisComplete }: StoryIntelligenceProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<StoryAnalysis | null>(null)
  const [analysisProgress, setAnalysisProgress] = useState(0)

  const analyzeStory = async () => {
    setIsAnalyzing(true)
    setAnalysisProgress(0)

    // Simulate IBM Granite analysis steps
    const steps = [
      "Analyzing narrative structure...",
      "Identifying emotional patterns...",
      "Mapping character personalities...",
      "Evaluating pacing and flow...",
      "Generating voice recommendations...",
      "Creating audience insights...",
      "Optimizing for audio experience...",
    ]

    for (let i = 0; i < steps.length; i++) {
      setAnalysisProgress(((i + 1) / steps.length) * 100)
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }

    // Mock analysis results (in real implementation, this would call IBM Granite)
    const mockAnalysis: StoryAnalysis = {
      emotionalTone: {
        primary: "Adventurous",
        secondary: "Mysterious",
        intensity: 75,
        timeline: [
          { chapter: "Chapter 1", emotion: "Curious", intensity: 60 },
          { chapter: "Chapter 2", emotion: "Exciting", intensity: 85 },
          { chapter: "Chapter 3", emotion: "Tense", intensity: 90 },
        ],
      },
      characters: [
        {
          name: "Aria",
          personality: "Brave, curious, determined",
          voiceSuggestion: "Young female, warm tone",
          emotionalArc: "Growth from uncertainty to confidence",
        },
        {
          name: "Master Theron",
          personality: "Wise, mysterious, protective",
          voiceSuggestion: "Older male, authoritative yet kind",
          emotionalArc: "Mentor revealing hidden knowledge",
        },
      ],
      pacing: {
        overall: "Well-balanced with good tension buildup",
        recommendations: [
          "Add 2-second pause after dramatic revelations",
          "Slow down during descriptive passages",
          "Increase pace during action sequences",
        ],
        optimalBreaks: [450, 890, 1340], // word positions
      },
      audienceAnalysis: {
        targetAge: "Young Adult (16-25)",
        complexity: 7,
        engagement: 8.5,
        recommendations: [
          "Perfect for fantasy audiobook listeners",
          "Consider adding sound effects for magical elements",
          "Voice should emphasize wonder and discovery",
        ],
      },
      voiceRecommendations: [
        {
          character: "Narrator",
          voice: "Emma (Warm Female)",
          reasoning: "Matches the adventurous yet mysterious tone",
          emotionalRange: ["Wonder", "Excitement", "Tension", "Hope"],
        },
        {
          character: "Aria",
          voice: "Sofia (Gentle Female)",
          reasoning: "Conveys youth and determination",
          emotionalRange: ["Curiosity", "Determination", "Fear", "Joy"],
        },
      ],
    }

    setAnalysis(mockAnalysis)
    onAnalysisComplete(mockAnalysis)
    setIsAnalyzing(false)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              IBM Granite Story Intelligence
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative space-y-6">
          {!analysis && !isAnalyzing && (
            <div className="text-center py-8">
              <div className="w-24 h-24 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-3xl mx-auto mb-6 flex items-center justify-center">
                <Lightbulb className="h-12 w-12 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Unlock Your Story's Potential</h3>
              <p className="text-gray-300 mb-6 max-w-md mx-auto">
                Let IBM Granite AI analyze your story to provide intelligent voice recommendations, emotional mapping,
                and audience insights.
              </p>
              <Button
                onClick={analyzeStory}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 px-8 py-3 rounded-2xl text-lg font-semibold"
              >
                <Brain className="h-5 w-5 mr-2" />
                Analyze Story with AI
              </Button>
            </div>
          )}

          {isAnalyzing && (
            <div className="text-center py-8">
              <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-blue-500 rounded-3xl mx-auto mb-6 flex items-center justify-center animate-pulse">
                <Brain className="h-12 w-12 text-white animate-pulse" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">AI Analysis in Progress</h3>
              <Progress value={analysisProgress} className="w-full max-w-md mx-auto mb-4" />
              <p className="text-gray-300">IBM Granite is analyzing your story...</p>
            </div>
          )}

          {analysis && (
            <div className="space-y-6">
              {/* Emotional Analysis */}
              <Card className="bg-black/20 border-white/10 rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <Heart className="h-5 w-5 text-red-400" />
                    <span>Emotional Intelligence</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-white">Primary Tone:</span>
                    <Badge className="bg-gradient-to-r from-purple-500 to-blue-500">
                      {analysis.emotionalTone.primary}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white">Secondary Tone:</span>
                    <Badge variant="outline" className="border-purple-400 text-purple-300">
                      {analysis.emotionalTone.secondary}
                    </Badge>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm text-gray-300 mb-2">
                      <span>Emotional Intensity</span>
                      <span>{analysis.emotionalTone.intensity}%</span>
                    </div>
                    <Progress value={analysis.emotionalTone.intensity} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              {/* Character Analysis */}
              <Card className="bg-black/20 border-white/10 rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <Users className="h-5 w-5 text-green-400" />
                    <span>Character Insights</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analysis.characters.map((character, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-xl border border-green-500/20"
                    >
                      <h4 className="font-bold text-white mb-2">{character.name}</h4>
                      <p className="text-gray-300 text-sm mb-2">{character.personality}</p>
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                          {character.voiceSuggestion}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Voice Recommendations */}
              <Card className="bg-black/20 border-white/10 rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <Target className="h-5 w-5 text-blue-400" />
                    <span>AI Voice Recommendations</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analysis.voiceRecommendations.map((rec, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl border border-blue-500/20"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-white">{rec.character}</h4>
                        <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">{rec.voice}</Badge>
                      </div>
                      <p className="text-gray-300 text-sm mb-3">{rec.reasoning}</p>
                      <div className="flex flex-wrap gap-2">
                        {rec.emotionalRange.map((emotion, i) => (
                          <Badge key={i} variant="outline" className="border-purple-400/50 text-purple-300 text-xs">
                            {emotion}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Audience Analysis */}
              <Card className="bg-black/20 border-white/10 rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-lg">
                    <TrendingUp className="h-5 w-5 text-yellow-400" />
                    <span>Audience Intelligence</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-yellow-500/20 rounded-xl">
                      <p className="text-yellow-300 font-semibold">Target Age</p>
                      <p className="text-white">{analysis.audienceAnalysis.targetAge}</p>
                    </div>
                    <div className="text-center p-3 bg-orange-500/20 rounded-xl">
                      <p className="text-orange-300 font-semibold">Engagement Score</p>
                      <p className="text-white">{analysis.audienceAnalysis.engagement}/10</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-white">AI Recommendations:</h4>
                    {analysis.audienceAnalysis.recommendations.map((rec, index) => (
                      <div key={index} className="flex items-center space-x-2 text-gray-300">
                        <Sparkles className="h-4 w-4 text-yellow-400" />
                        <span className="text-sm">{rec}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
