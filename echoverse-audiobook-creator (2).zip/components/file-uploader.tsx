"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, FileText, CheckCircle, AlertCircle, Sparkles, Zap } from "lucide-react"

interface FileUploaderProps {
  onTextExtracted: (text: string) => void
}

export function FileUploader({ onTextExtracted }: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "success" | "error">("idle")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (file: File) => {
    if (!file) return

    setIsProcessing(true)
    setUploadStatus("idle")

    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const content = e.target?.result as string

        // Extract text based on file type
        let extractedText = ""

        if (file.type === "text/plain" || file.name.endsWith(".txt")) {
          extractedText = content
        } else if (file.type === "application/json" || file.name.endsWith(".json")) {
          // Try to extract text from JSON
          try {
            const jsonData = JSON.parse(content)
            extractedText = JSON.stringify(jsonData, null, 2)
          } catch {
            extractedText = content
          }
        } else {
          // For other file types, try to extract as plain text
          extractedText = content
        }

        if (extractedText.trim()) {
          onTextExtracted(extractedText.trim())
          setUploadStatus("success")
        } else {
          setUploadStatus("error")
        }
      } catch (error) {
        console.error("Error processing file:", error)
        setUploadStatus("error")
      } finally {
        setIsProcessing(false)
      }
    }

    reader.onerror = () => {
      setUploadStatus("error")
      setIsProcessing(false)
    }

    reader.readAsText(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  return (
    <div className="space-y-8">
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-transparent to-purple-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl">
              <Upload className="h-6 w-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Upload Your Story
            </span>
          </CardTitle>
          <CardDescription className="text-lg text-gray-300">
            Drop your text file here or browse to upload. We'll extract and prepare it for audio conversion.
          </CardDescription>
        </CardHeader>
        <CardContent className="relative space-y-6">
          {/* File Drop Zone */}
          <div
            className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
              isDragging
                ? "border-purple-400 bg-purple-500/20 scale-105"
                : "border-white/30 hover:border-white/50 hover:bg-white/5"
            }`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
          >
            {/* Animated background effect */}
            <div className="absolute inset-0 rounded-2xl overflow-hidden">
              <div
                className={`absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 transition-opacity duration-300 ${isDragging ? "opacity-100" : "opacity-0"}`}
              ></div>
            </div>

            <div className="relative flex flex-col items-center space-y-6">
              <div className="relative">
                <div
                  className={`absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-3xl blur-lg transition-all duration-300 ${isProcessing ? "animate-pulse" : ""}`}
                ></div>
                <div className="relative p-6 bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-3xl border border-white/20">
                  <FileText
                    className={`h-12 w-12 text-blue-400 transition-transform duration-300 ${isDragging ? "scale-110 rotate-12" : ""}`}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-2xl font-bold text-white">
                  {isProcessing ? (
                    <span className="flex items-center space-x-2">
                      <Zap className="h-6 w-6 animate-spin" />
                      <span>Processing your file...</span>
                    </span>
                  ) : isDragging ? (
                    "Drop it like it's hot! 🔥"
                  ) : (
                    "Drop your file here"
                  )}
                </h3>
                <p className="text-gray-400 text-lg">Supports: .txt, .json, .md, .csv and other text formats</p>
              </div>

              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessing}
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-4 rounded-2xl text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                {isProcessing ? (
                  <>
                    <Zap className="h-5 w-5 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Upload className="h-5 w-5 mr-2" />
                    Browse Files
                  </>
                )}
              </Button>

              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,.json,.md,.csv"
                onChange={handleFileInputChange}
                className="hidden"
              />
            </div>
          </div>

          {/* Status Messages */}
          {uploadStatus === "success" && (
            <div className="flex items-center space-x-3 p-6 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-2xl border border-green-500/30 backdrop-blur-sm animate-slide-up">
              <div className="p-2 bg-green-500 rounded-xl">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-green-300 text-lg">Success!</h4>
                <p className="text-green-200">File uploaded and text extracted successfully!</p>
              </div>
            </div>
          )}

          {uploadStatus === "error" && (
            <div className="flex items-center space-x-3 p-6 bg-gradient-to-r from-red-500/20 to-pink-500/20 rounded-2xl border border-red-500/30 backdrop-blur-sm animate-slide-up">
              <div className="p-2 bg-red-500 rounded-xl">
                <AlertCircle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-red-300 text-lg">Oops!</h4>
                <p className="text-red-200">Error processing file. Please try a different file.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Supported Formats Card */}
      <Card className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-2xl">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Sparkles className="h-5 w-5 text-purple-400" />
            <h4 className="font-semibold text-white text-lg">Supported File Types</h4>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { ext: ".txt", desc: "Plain text files", color: "from-blue-500 to-blue-600" },
              { ext: ".json", desc: "JSON data files", color: "from-green-500 to-green-600" },
              { ext: ".md", desc: "Markdown files", color: "from-purple-500 to-purple-600" },
              { ext: ".csv", desc: "CSV files", color: "from-orange-500 to-orange-600" },
            ].map((format) => (
              <div
                key={format.ext}
                className="p-4 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all duration-300"
              >
                <div
                  className={`w-8 h-8 bg-gradient-to-r ${format.color} rounded-lg mb-2 flex items-center justify-center`}
                >
                  <span className="text-white font-bold text-sm">{format.ext.slice(1).toUpperCase()}</span>
                </div>
                <p className="text-white font-medium">{format.ext}</p>
                <p className="text-gray-400 text-sm">{format.desc}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
