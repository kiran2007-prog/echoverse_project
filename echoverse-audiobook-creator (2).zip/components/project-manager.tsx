"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FolderOpen, Plus, BookOpen, Clock, FileAudio } from "lucide-react"

interface Project {
  id: string
  name: string
  status: "draft" | "processing" | "completed"
  wordCount: number
  duration: number
  createdAt: string
}

interface ProjectManagerProps {
  activeProject: Project | null
  onProjectSelect: (project: Project | null) => void
}

export function ProjectManager({ activeProject, onProjectSelect }: ProjectManagerProps) {
  const [projects] = useState<Project[]>([
    {
      id: "1",
      name: "The Enchanted Forest",
      status: "completed",
      wordCount: 2500,
      duration: 18,
      createdAt: "2024-01-15",
    },
    {
      id: "2",
      name: "Mystery of the Lost City",
      status: "processing",
      wordCount: 1800,
      duration: 12,
      createdAt: "2024-01-14",
    },
    {
      id: "3",
      name: "Space Adventure Chronicles",
      status: "draft",
      wordCount: 950,
      duration: 6,
      createdAt: "2024-01-13",
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500/20 text-green-400"
      case "processing":
        return "bg-yellow-500/20 text-yellow-400"
      case "draft":
        return "bg-gray-500/20 text-gray-400"
      default:
        return "bg-gray-500/20 text-gray-400"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <FileAudio className="h-3 w-3" />
      case "processing":
        return <Clock className="h-3 w-3" />
      case "draft":
        return <BookOpen className="h-3 w-3" />
      default:
        return <BookOpen className="h-3 w-3" />
    }
  }

  return (
    <Card className="bg-black/40 border-white/10 text-white">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FolderOpen className="h-5 w-5 text-orange-400" />
            <span>Projects</span>
          </div>
          <Button size="sm" variant="ghost" className="text-white hover:bg-white/10">
            <Plus className="h-4 w-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {projects.map((project) => (
          <div
            key={project.id}
            className={`p-3 rounded-lg border cursor-pointer transition-all ${
              activeProject?.id === project.id
                ? "bg-purple-600/30 border-purple-500"
                : "bg-black/20 border-white/10 hover:bg-white/5"
            }`}
            onClick={() => onProjectSelect(project)}
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-white text-sm truncate">{project.name}</h4>
              <Badge className={`text-xs ${getStatusColor(project.status)}`}>
                {getStatusIcon(project.status)}
                <span className="ml-1 capitalize">{project.status}</span>
              </Badge>
            </div>
            <div className="flex justify-between text-xs text-gray-400">
              <span>{project.wordCount} words</span>
              <span>{project.duration} min</span>
            </div>
            <div className="text-xs text-gray-500 mt-1">{new Date(project.createdAt).toLocaleDateString()}</div>
          </div>
        ))}

        <Button
          variant="outline"
          className="w-full border-white/20 text-white hover:bg-white/10 border-dashed bg-transparent"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Project
        </Button>
      </CardContent>
    </Card>
  )
}
