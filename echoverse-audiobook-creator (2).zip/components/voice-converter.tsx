"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import {
  Play,
  Pause,
  Download,
  Mic,
  Volume2,
  Settings,
  AlertCircle,
  RefreshCw,
  Sparkles,
  Zap,
  Headphones,
} from "lucide-react"

interface VoiceConverterProps {
  text: string
  selectedVoice: string
  onVoiceSelect: (voice: string) => void
}

const voices = [
  {
    id: "neural-voice-1",
    name: "Emma",
    description: "Warm female voice",
    gender: "female",
    accent: "American",
    color: "from-pink-500 to-rose-500",
  },
  {
    id: "neural-voice-2",
    name: "James",
    description: "Professional male voice",
    gender: "male",
    accent: "British",
    color: "from-blue-500 to-indigo-500",
  },
  {
    id: "neural-voice-3",
    name: "Sofia",
    description: "Gentle female voice",
    gender: "female",
    accent: "International",
    color: "from-purple-500 to-violet-500",
  },
  {
    id: "neural-voice-4",
    name: "Marcus",
    description: "Dynamic male voice",
    gender: "male",
    accent: "American",
    color: "from-green-500 to-emerald-500",
  },
]

export function VoiceConverter({ text, selectedVoice, onVoiceSelect }: VoiceConverterProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [speed, setSpeed] = useState([1.0])
  const [pitch, setPitch] = useState([1.0])
  const [volume, setVolume] = useState([0.8])
  const [isConverting, setIsConverting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [voicesLoaded, setVoicesLoaded] = useState(false)
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([])
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null)
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Initialize speech synthesis and load voices
  useEffect(() => {
    if (!("speechSynthesis" in window)) {
      setError("Speech synthesis is not supported in your browser. Please use Chrome, Firefox, or Safari.")
      return
    }

    const loadVoices = () => {
      try {
        const voices = speechSynthesis.getVoices()
        console.log("Available voices:", voices.length)

        if (voices.length > 0) {
          setAvailableVoices(voices)
          setVoicesLoaded(true)
          console.log(
            "Voices loaded:",
            voices.map((v) => `${v.name} (${v.lang})`),
          )
        }
      } catch (err) {
        console.error("Error loading voices:", err)
        setError("Failed to load voices. Please refresh the page.")
      }
    }

    loadVoices()

    const handleVoicesChanged = () => {
      console.log("Voices changed event fired")
      loadVoices()
    }

    speechSynthesis.addEventListener("voiceschanged", handleVoicesChanged)

    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current)
      }
      speechSynthesis.removeEventListener("voiceschanged", handleVoicesChanged)
      speechSynthesis.cancel()
    }
  }, [])

  const findBestVoice = (preferredGender: string): SpeechSynthesisVoice | null => {
    if (availableVoices.length === 0) return null

    let voice = null

    if (preferredGender === "female") {
      voice = availableVoices.find(
        (v) =>
          v.name.toLowerCase().includes("female") ||
          v.name.toLowerCase().includes("woman") ||
          v.name.toLowerCase().includes("samantha") ||
          v.name.toLowerCase().includes("karen") ||
          v.name.toLowerCase().includes("susan") ||
          v.name.toLowerCase().includes("victoria") ||
          v.name.toLowerCase().includes("zira") ||
          (v.gender && v.gender === "female"),
      )
    } else {
      voice = availableVoices.find(
        (v) =>
          v.name.toLowerCase().includes("male") ||
          v.name.toLowerCase().includes("man") ||
          v.name.toLowerCase().includes("david") ||
          v.name.toLowerCase().includes("mark") ||
          v.name.toLowerCase().includes("daniel") ||
          v.name.toLowerCase().includes("alex") ||
          (v.gender && v.gender === "male"),
      )
    }

    if (!voice) {
      voice = availableVoices.find((v) => v.default) || availableVoices[0]
    }

    return voice
  }

  const convertToSpeech = async () => {
    if (!text.trim()) {
      setError("Please enter some text first!")
      return
    }

    if (!("speechSynthesis" in window)) {
      setError("Speech synthesis is not supported in your browser.")
      return
    }

    setError(null)

    if (isPlaying) {
      try {
        speechSynthesis.cancel()
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current)
        }
        setIsPlaying(false)
        setCurrentTime(0)
        return
      } catch (err) {
        console.error("Error stopping speech:", err)
      }
    }

    setIsConverting(true)

    try {
      speechSynthesis.cancel()
      await new Promise((resolve) => setTimeout(resolve, 200))

      if (!voicesLoaded || availableVoices.length === 0) {
        setError("Voices are still loading. Please wait a moment and try again.")
        setIsConverting(false)
        return
      }

      const maxLength = 300
      const textToSpeak = text.length > maxLength ? text.substring(0, maxLength).trim() + "..." : text.trim()

      if (!textToSpeak) {
        setError("No text to convert.")
        setIsConverting(false)
        return
      }

      const utterance = new SpeechSynthesisUtterance(textToSpeak)
      utteranceRef.current = utterance

      const selectedVoiceData = voices.find((v) => v.id === selectedVoice)
      const browserVoice = findBestVoice(selectedVoiceData?.gender || "female")

      if (browserVoice) {
        utterance.voice = browserVoice
        console.log("Using voice:", browserVoice.name)
      } else {
        console.log("No specific voice found, using default")
      }

      utterance.rate = Math.max(0.1, Math.min(3.0, speed[0]))
      utterance.pitch = Math.max(0.1, Math.min(2.0, pitch[0]))
      utterance.volume = Math.max(0.1, Math.min(1.0, volume[0]))
      utterance.lang = "en-US"

      const words = textToSpeak.split(" ").length
      const estimatedDuration = Math.ceil(((words / 150) * 60) / speed[0])
      setDuration(estimatedDuration)

      utterance.onstart = () => {
        console.log("Speech started successfully")
        setIsPlaying(true)
        setIsConverting(false)
        setCurrentTime(0)
        setError(null)

        progressIntervalRef.current = setInterval(() => {
          if (speechSynthesis.speaking && !speechSynthesis.paused) {
            setCurrentTime((prev) => {
              const newTime = prev + 1
              if (newTime >= estimatedDuration) {
                if (progressIntervalRef.current) {
                  clearInterval(progressIntervalRef.current)
                }
                return estimatedDuration
              }
              return newTime
            })
          } else if (!speechSynthesis.speaking) {
            if (progressIntervalRef.current) {
              clearInterval(progressIntervalRef.current)
            }
          }
        }, 1000)
      }

      utterance.onend = () => {
        console.log("Speech ended")
        setIsPlaying(false)
        setIsConverting(false)
        setCurrentTime(0)
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current)
        }
      }

      utterance.onerror = (event) => {
        console.error("Speech synthesis error:", event)
        setIsPlaying(false)
        setIsConverting(false)
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current)
        }

        let errorMessage = "Speech conversion failed. "

        if (event.error === "network") {
          errorMessage += "Please check your internet connection and try again."
        } else if (event.error === "synthesis-failed") {
          errorMessage += "Try using shorter text or refresh the page."
        } else if (event.error === "synthesis-unavailable") {
          errorMessage += "Speech synthesis is temporarily unavailable. Please try again later."
        } else if (event.error === "language-unavailable") {
          errorMessage += "The selected language is not available."
        } else if (event.error === "voice-unavailable") {
          errorMessage += "The selected voice is not available."
        } else if (event.error === "text-too-long") {
          errorMessage += "The text is too long. Please use shorter text."
        } else if (event.error === "rate-not-supported") {
          errorMessage += "The speech rate is not supported. Try different speed settings."
        } else {
          errorMessage += "Please try again or use a different browser."
        }

        setError(errorMessage)
      }

      utterance.onpause = () => {
        console.log("Speech paused")
        setIsPlaying(false)
      }

      utterance.onresume = () => {
        console.log("Speech resumed")
        setIsPlaying(true)
      }

      try {
        console.log("Starting speech synthesis...")
        speechSynthesis.speak(utterance)

        setTimeout(() => {
          if (isConverting) {
            setIsConverting(false)
            setError("Speech synthesis timed out. Please try with shorter text or refresh the page.")
          }
        }, 3000)
      } catch (err) {
        console.error("Error starting speech:", err)
        setIsConverting(false)
        setError("Failed to start speech synthesis. Please try again.")
      }
    } catch (error) {
      console.error("Error in convertToSpeech:", error)
      setIsPlaying(false)
      setIsConverting(false)
      setError("An unexpected error occurred. Please refresh the page and try again.")
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const testVoice = async (voiceId: string) => {
    if (!voicesLoaded || availableVoices.length === 0) {
      setError("Voices are still loading. Please wait a moment.")
      return
    }

    try {
      speechSynthesis.cancel()
      await new Promise((resolve) => setTimeout(resolve, 100))

      const testText = "Hello, this is a voice test for EchoVerse."
      const utterance = new SpeechSynthesisUtterance(testText)

      const selectedVoiceData = voices.find((v) => v.id === voiceId)
      const browserVoice = findBestVoice(selectedVoiceData?.gender || "female")

      if (browserVoice) {
        utterance.voice = browserVoice
      }

      utterance.rate = speed[0]
      utterance.pitch = pitch[0]
      utterance.volume = volume[0]

      utterance.onerror = (event) => {
        console.error("Voice test error:", event)
        setError("Voice test failed. Please try a different voice.")
      }

      speechSynthesis.speak(utterance)
    } catch (err) {
      console.error("Error testing voice:", err)
      setError("Voice test failed. Please try again.")
    }
  }

  const refreshVoices = () => {
    setVoicesLoaded(false)
    setAvailableVoices([])
    setError(null)

    speechSynthesis.cancel()
    const voices = speechSynthesis.getVoices()
    if (voices.length > 0) {
      setAvailableVoices(voices)
      setVoicesLoaded(true)
    }
  }

  return (
    <div className="space-y-8">
      {/* Error Display */}
      {error && (
        <Card className="bg-gradient-to-r from-red-500/20 to-pink-500/20 border border-red-500/30 backdrop-blur-xl rounded-2xl animate-slide-up">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-500 rounded-xl">
                  <AlertCircle className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-red-300 text-lg">Oops!</h4>
                  <p className="text-red-200">{error}</p>
                </div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={refreshVoices}
                className="text-red-300 hover:text-red-200 hover:bg-red-500/20 rounded-xl"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Voice Selection */}
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center justify-between text-2xl">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl">
                <Mic className="h-6 w-6 text-white" />
              </div>
              <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                Choose Your Voice
              </span>
            </div>
            <div className="flex items-center space-x-3">
              {!voicesLoaded && (
                <div className="flex items-center space-x-2 px-3 py-1 bg-yellow-500/20 rounded-full border border-yellow-500/30">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                  <span className="text-xs text-yellow-300">Loading voices...</span>
                </div>
              )}
              <Button
                size="sm"
                variant="ghost"
                onClick={refreshVoices}
                className="text-gray-400 hover:text-white hover:bg-white/10 rounded-xl"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </CardTitle>
          <CardDescription className="text-lg text-gray-300">
            Select the perfect narrator for your story ({availableVoices.length} voices available)
          </CardDescription>
        </CardHeader>
        <CardContent className="relative space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {voices.map((voice) => (
              <Card
                key={voice.id}
                className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                  selectedVoice === voice.id
                    ? "bg-gradient-to-br from-purple-600/30 to-blue-600/30 border-purple-500 shadow-lg shadow-purple-500/25"
                    : "bg-black/20 border-white/10 hover:bg-white/5 hover:border-white/20"
                }`}
                onClick={() => onVoiceSelect(voice.id)}
              >
                <CardContent className="p-6 text-center">
                  <div className="relative mb-4">
                    <div
                      className={`absolute inset-0 bg-gradient-to-r ${voice.color} rounded-2xl blur-lg opacity-75 animate-pulse`}
                    ></div>
                    <div
                      className={`relative w-16 h-16 bg-gradient-to-r ${voice.color} rounded-2xl mx-auto flex items-center justify-center`}
                    >
                      <Headphones className="h-8 w-8 text-white" />
                    </div>
                  </div>
                  <h4 className="font-bold text-white text-lg mb-2">{voice.name}</h4>
                  <p className="text-sm text-gray-300 mb-1">{voice.description}</p>
                  <p className="text-xs text-gray-400 mb-4">{voice.accent} accent</p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-500/20 rounded-xl transition-all duration-300"
                    onClick={(e) => {
                      e.stopPropagation()
                      testVoice(voice.id)
                    }}
                    disabled={!voicesLoaded}
                  >
                    <Play className="h-3 w-3 mr-1" />
                    Test Voice
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Voice Settings */}
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 via-transparent to-orange-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl">
              <Settings className="h-6 w-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Voice Settings
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <Label className="text-white text-lg font-medium flex items-center space-x-2">
                <Zap className="h-4 w-4 text-yellow-400" />
                <span>Speed: {speed[0]}x</span>
              </Label>
              <div className="p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-2xl border border-yellow-500/20">
                <Slider value={speed} onValueChange={setSpeed} max={2} min={0.5} step={0.1} className="w-full" />
              </div>
            </div>
            <div className="space-y-3">
              <Label className="text-white text-lg font-medium flex items-center space-x-2">
                <Sparkles className="h-4 w-4 text-purple-400" />
                <span>Pitch: {pitch[0]}x</span>
              </Label>
              <div className="p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-2xl border border-purple-500/20">
                <Slider value={pitch} onValueChange={setPitch} max={1.5} min={0.5} step={0.1} className="w-full" />
              </div>
            </div>
            <div className="space-y-3">
              <Label className="text-white text-lg font-medium flex items-center space-x-2">
                <Volume2 className="h-4 w-4 text-blue-400" />
                <span>Volume: {Math.round(volume[0] * 100)}%</span>
              </Label>
              <div className="p-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-2xl border border-blue-500/20">
                <Slider value={volume} onValueChange={setVolume} max={1} min={0} step={0.1} className="w-full" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Audio Player */}
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 via-transparent to-blue-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-3 bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl">
              <Volume2 className="h-6 w-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">Audio Player</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative space-y-6">
          {/* Waveform Visualization */}
          <div className="relative h-24 bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-2xl flex items-center justify-center border border-white/10 backdrop-blur-sm overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 opacity-50"></div>
            <div className="relative flex items-end space-x-1 h-16">
              {Array.from({ length: 40 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-1.5 bg-gradient-to-t from-purple-500 to-blue-500 rounded-full transition-all duration-300 ${
                    isPlaying ? "animate-pulse" : ""
                  }`}
                  style={{
                    height: `${Math.random() * 100}%`,
                    opacity: duration > 0 && i < (currentTime / duration) * 40 ? 1 : 0.4,
                    animationDelay: `${i * 0.1}s`,
                  }}
                />
              ))}
            </div>
          </div>

          {/* Progress */}
          <div className="space-y-3">
            <div className="p-4 bg-black/20 rounded-2xl border border-white/10">
              <Slider value={[currentTime]} max={duration || 100} step={1} className="w-full" disabled />
            </div>
            <div className="flex justify-between text-lg text-gray-300 font-medium">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center space-x-6">
            <Button
              size="lg"
              onClick={convertToSpeech}
              disabled={!text.trim() || isConverting || !voicesLoaded}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-2xl px-12 py-6 text-xl font-bold transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
            >
              {isConverting ? (
                <>
                  <RefreshCw className="h-6 w-6 mr-3 animate-spin" />
                  Converting...
                </>
              ) : isPlaying ? (
                <>
                  <Pause className="h-6 w-6 mr-3" />
                  Stop
                </>
              ) : (
                <>
                  <Play className="h-6 w-6 mr-3" />
                  Convert to Speech
                </>
              )}
            </Button>
          </div>

          {/* Text Length Warning */}
          {text.length > 300 && (
            <div className="p-6 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-2xl border border-yellow-500/30 backdrop-blur-sm animate-slide-up">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-yellow-500 rounded-xl">
                  <AlertCircle className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-yellow-300 text-lg">Long text detected</h4>
                  <p className="text-yellow-200">
                    For better reliability, consider using shorter text (under 300 characters). Current length:{" "}
                    {text.length} characters.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Download Button */}
          <Button
            variant="outline"
            className="w-full border-white/30 text-white hover:bg-gradient-to-r hover:from-purple-500/20 hover:to-blue-500/20 bg-transparent rounded-2xl py-4 text-lg font-semibold transition-all duration-300 hover:scale-105"
            disabled={!text.trim()}
          >
            <Download className="h-5 w-5 mr-3" />
            Export Audio (Coming Soon)
          </Button>
        </CardContent>
      </Card>

      {/* Instructions */}
      {!text && (
        <Card className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-500/30 backdrop-blur-xl rounded-2xl animate-fade-in">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-blue-500 rounded-xl">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <h4 className="font-bold text-blue-300 text-lg">How to use EchoVerse</h4>
            </div>
            <ol className="text-gray-300 space-y-2 list-decimal list-inside">
              <li className="text-lg">Upload a text file OR type your text manually</li>
              <li className="text-lg">Wait for voices to load (you'll see the count above)</li>
              <li className="text-lg">Choose your preferred voice and test it</li>
              <li className="text-lg">Adjust speed, pitch, and volume settings</li>
              <li className="text-lg">Click "Convert to Speech" to hear your text</li>
            </ol>
          </CardContent>
        </Card>
      )}

      {/* Browser Compatibility Info */}
      <Card className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-2xl">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3 mb-4">
            <RefreshCw className="h-5 w-5 text-gray-400" />
            <h4 className="font-semibold text-white text-lg">Troubleshooting Tips</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="text-gray-300 space-y-2 list-disc list-inside">
              <li>Try refreshing the page</li>
              <li>Use shorter text (under 300 characters)</li>
              <li>Switch to Chrome or Firefox for best compatibility</li>
            </ul>
            <ul className="text-gray-300 space-y-2 list-disc list-inside">
              <li>Check that your browser allows audio playback</li>
              <li>Ensure your device volume is turned up</li>
              <li>Disable browser extensions that might interfere</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
