"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import {
  Heart,
  Zap,
  Smile,
  Frown,
  Meh,
  Angry,
  AngryIcon as Surprised,
  Play,
  Pause,
  Settings,
  Palette,
} from "lucide-react"

interface EmotionalVoiceEngineProps {
  text: string
  selectedEmotion: string
  onEmotionChange: (emotion: string, intensity: number) => void
}

const emotions = [
  {
    id: "joy",
    name: "Joyful",
    icon: Smile,
    color: "from-yellow-500 to-orange-500",
    description: "Bright, uplifting, energetic",
  },
  {
    id: "sadness",
    name: "Melancholic",
    icon: Frown,
    color: "from-blue-500 to-indigo-500",
    description: "Gentle, reflective, touching",
  },
  {
    id: "excitement",
    name: "Thrilling",
    icon: Zap,
    color: "from-red-500 to-pink-500",
    description: "Fast-paced, dynamic, engaging",
  },
  {
    id: "calm",
    name: "Serene",
    icon: Meh,
    color: "from-green-500 to-teal-500",
    description: "Peaceful, steady, soothing",
  },
  {
    id: "mysterious",
    name: "Enigmatic",
    icon: Surprised,
    color: "from-purple-500 to-violet-500",
    description: "Intriguing, suspenseful, captivating",
  },
  {
    id: "dramatic",
    name: "Intense",
    icon: Angry,
    color: "from-red-600 to-red-800",
    description: "Powerful, commanding, impactful",
  },
]

export function EmotionalVoiceEngine({ text, selectedEmotion, onEmotionChange }: EmotionalVoiceEngineProps) {
  const [intensity, setIntensity] = useState([70])
  const [isPlaying, setIsPlaying] = useState(false)
  const [emotionalCurve, setEmotionalCurve] = useState([
    { time: 0, emotion: "calm", intensity: 50 },
    { time: 25, emotion: "excitement", intensity: 80 },
    { time: 50, emotion: "mysterious", intensity: 60 },
    { time: 75, emotion: "joy", intensity: 90 },
    { time: 100, emotion: "calm", intensity: 40 },
  ])

  const handleEmotionSelect = (emotionId: string) => {
    onEmotionChange(emotionId, intensity[0])
  }

  const playEmotionalPreview = () => {
    setIsPlaying(!isPlaying)
    // In real implementation, this would trigger emotional TTS
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/30 backdrop-blur-xl border border-white/20 shadow-2xl rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-500/10 via-transparent to-purple-500/10"></div>
        <CardHeader className="relative">
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl">
              <Heart className="h-6 w-6 text-white" />
            </div>
            <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              Emotional Voice Engine
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative space-y-6">
          {/* Emotion Selection */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {emotions.map((emotion) => {
              const Icon = emotion.icon
              return (
                <Card
                  key={emotion.id}
                  className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedEmotion === emotion.id
                      ? "bg-gradient-to-br from-purple-600/30 to-pink-600/30 border-purple-500 shadow-lg"
                      : "bg-black/20 border-white/10 hover:bg-white/5"
                  }`}
                  onClick={() => handleEmotionSelect(emotion.id)}
                >
                  <CardContent className="p-4 text-center">
                    <div
                      className={`w-12 h-12 bg-gradient-to-r ${emotion.color} rounded-2xl mx-auto mb-3 flex items-center justify-center`}
                    >
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h4 className="font-bold text-white mb-1">{emotion.name}</h4>
                    <p className="text-xs text-gray-400">{emotion.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Intensity Control */}
          <Card className="bg-black/20 border-white/10 rounded-2xl">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Settings className="h-5 w-5 text-blue-400" />
                <span>Emotional Intensity</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between text-white">
                  <span>Intensity Level</span>
                  <span className="font-bold">{intensity[0]}%</span>
                </div>
                <Slider value={intensity} onValueChange={setIntensity} max={100} min={10} step={5} className="w-full" />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Subtle</span>
                  <span>Moderate</span>
                  <span>Intense</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Emotional Curve Visualization */}
          <Card className="bg-black/20 border-white/10 rounded-2xl">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Palette className="h-5 w-5 text-purple-400" />
                <span>Emotional Journey</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-32 bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-xl p-4 relative overflow-hidden">
                <div className="absolute inset-0 flex items-end justify-between px-4 pb-4">
                  {emotionalCurve.map((point, index) => {
                    const emotion = emotions.find((e) => e.id === point.emotion)
                    const Icon = emotion?.icon || Heart
                    return (
                      <div key={index} className="flex flex-col items-center space-y-2">
                        <div
                          className={`w-8 h-8 bg-gradient-to-r ${emotion?.color || "from-gray-500 to-gray-600"} rounded-lg flex items-center justify-center transition-all duration-300`}
                          style={{ transform: `translateY(-${point.intensity * 0.5}px)` }}
                        >
                          <Icon className="h-4 w-4 text-white" />
                        </div>
                        <div className="text-xs text-gray-400">{point.time}%</div>
                      </div>
                    )
                  })}
                </div>
                {/* Connecting line */}
                <svg className="absolute inset-0 w-full h-full">
                  <path
                    d={`M ${emotionalCurve
                      .map(
                        (point, index) => `${(index / (emotionalCurve.length - 1)) * 100}% ${100 - point.intensity}%`,
                      )
                      .join(" L ")}`}
                    stroke="url(#gradient)"
                    strokeWidth="2"
                    fill="none"
                    className="opacity-60"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#8B5CF6" />
                      <stop offset="100%" stopColor="#EC4899" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </CardContent>
          </Card>

          {/* Preview Controls */}
          <div className="flex justify-center space-x-4">
            <Button
              onClick={playEmotionalPreview}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 px-8 py-3 rounded-2xl text-lg font-semibold"
            >
              {isPlaying ? (
                <>
                  <Pause className="h-5 w-5 mr-2" />
                  Stop Preview
                </>
              ) : (
                <>
                  <Play className="h-5 w-5 mr-2" />
                  Preview Emotional Voice
                </>
              )}
            </Button>
          </div>

          {/* Emotional Tags */}
          <div className="flex flex-wrap gap-2 justify-center">
            {["Warm", "Expressive", "Dynamic", "Nuanced", "Captivating"].map((tag) => (
              <Badge
                key={tag}
                className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border-purple-500/30"
              >
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
