"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Mic, Play, Pause, Settings } from "lucide-react"

interface VoiceSelectorProps {
  selectedVoice: string
  onVoiceSelect: (voice: string) => void
  text: string
}

const voices = [
  {
    id: "neural-voice-1",
    name: "Emma",
    description: "Warm, professional female narrator",
    accent: "American",
    sample: "A warm and engaging voice perfect for fiction and storytelling.",
  },
  {
    id: "neural-voice-2",
    name: "James",
    description: "Deep, authoritative male narrator",
    accent: "British",
    sample: "A commanding presence ideal for non-fiction and educational content.",
  },
  {
    id: "neural-voice-3",
    name: "Sofia",
    description: "Gentle, soothing female narrator",
    accent: "International",
    sample: "A calming voice that draws listeners into any narrative.",
  },
  {
    id: "neural-voice-4",
    name: "Marcus",
    description: "Dynamic, energetic male narrator",
    accent: "American",
    sample: "An enthusiastic voice that brings excitement to every story.",
  },
]

export function VoiceSelector({ selectedVoice, onVoiceSelect, text }: VoiceSelectorProps) {
  const [isPlaying, setIsPlaying] = useState<string | null>(null)
  const [speed, setSpeed] = useState([1.0])
  const [pitch, setPitch] = useState([1.0])
  const [volume, setVolume] = useState([0.8])

  const handlePlaySample = (voiceId: string) => {
    if (isPlaying === voiceId) {
      // Stop current playback
      speechSynthesis.cancel()
      setIsPlaying(null)
      return
    }

    // Stop any current playback
    speechSynthesis.cancel()

    // Wait for cancellation to complete
    setTimeout(() => {
      setIsPlaying(voiceId)

      // Get the voice sample text
      const voice = voices.find((v) => v.id === voiceId)
      if (voice && "speechSynthesis" in window) {
        const utterance = new SpeechSynthesisUtterance(voice.sample)

        // Get available voices
        let availableVoices = speechSynthesis.getVoices()

        // If no voices loaded, wait for them
        if (availableVoices.length === 0) {
          speechSynthesis.onvoiceschanged = () => {
            availableVoices = speechSynthesis.getVoices()
            proceedWithSpeech()
          }
        } else {
          proceedWithSpeech()
        }

        function proceedWithSpeech() {
          let selectedVoice = null

          if (voiceId === "neural-voice-1") {
            selectedVoice = availableVoices.find(
              (v) =>
                v.name.toLowerCase().includes("female") ||
                v.name.toLowerCase().includes("samantha") ||
                v.name.toLowerCase().includes("zira") ||
                (v.gender && v.gender === "female"),
            )
          } else if (voiceId === "neural-voice-2") {
            selectedVoice = availableVoices.find(
              (v) =>
                v.name.toLowerCase().includes("male") ||
                v.name.toLowerCase().includes("david") ||
                v.lang.includes("en-GB") ||
                (v.gender && v.gender === "male"),
            )
          }

          // Fallback to default or first available voice
          if (!selectedVoice) {
            selectedVoice = availableVoices.find((v) => v.default) || availableVoices[0]
          }

          if (selectedVoice) {
            utterance.voice = selectedVoice
          }

          // Set safe parameters
          utterance.rate = Math.max(0.1, Math.min(2.0, speed[0]))
          utterance.pitch = Math.max(0.1, Math.min(2.0, pitch[0]))
          utterance.volume = Math.max(0.1, Math.min(1.0, volume[0]))
          utterance.lang = "en-US"

          utterance.onend = () => setIsPlaying(null)
          utterance.onerror = (event) => {
            console.error("Voice sample error:", event.error)
            setIsPlaying(null)
          }

          try {
            speechSynthesis.speak(utterance)
          } catch (error) {
            console.error("Speech synthesis failed:", error)
            setIsPlaying(null)
          }
        }
      }
    }, 100)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mic className="h-5 w-5 text-blue-400" />
            <span>Voice Selection</span>
          </CardTitle>
          <CardDescription className="text-gray-300">
            Choose the perfect narrator voice for your audiobook
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {voices.map((voice) => (
              <Card
                key={voice.id}
                className={`cursor-pointer transition-all ${
                  selectedVoice === voice.id
                    ? "bg-purple-600/30 border-purple-500"
                    : "bg-black/20 border-white/10 hover:bg-white/5"
                }`}
                onClick={() => onVoiceSelect(voice.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-white">{voice.name}</h4>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation()
                        handlePlaySample(voice.id)
                      }}
                      className="text-white hover:bg-white/10"
                    >
                      {isPlaying === voice.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                  </div>
                  <p className="text-sm text-gray-300 mb-1">{voice.description}</p>
                  <p className="text-xs text-gray-400">{voice.accent} accent</p>
                  <p className="text-xs text-gray-500 mt-2 italic">"{voice.sample}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5 text-yellow-400" />
            <span>Voice Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-white mb-2 block">Speed: {speed[0]}x</Label>
            <Slider value={speed} onValueChange={setSpeed} max={2} min={0.5} step={0.1} className="w-full" />
          </div>

          <div>
            <Label className="text-white mb-2 block">Pitch: {pitch[0]}x</Label>
            <Slider value={pitch} onValueChange={setPitch} max={1.5} min={0.5} step={0.1} className="w-full" />
          </div>

          <div>
            <Label className="text-white mb-2 block">Volume: {Math.round(volume[0] * 100)}%</Label>
            <Slider value={volume} onValueChange={setVolume} max={1} min={0} step={0.1} className="w-full" />
          </div>

          {text && (
            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              onClick={() => handlePlaySample("preview")}
            >
              <Play className="h-4 w-4 mr-2" />
              Preview with Current Text
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
