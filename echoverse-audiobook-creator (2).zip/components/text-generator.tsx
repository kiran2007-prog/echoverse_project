"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sparkles, BookOpen, Wand2, RefreshCw } from "lucide-react"

interface TextGeneratorProps {
  onTextGenerated: (text: string) => void
  generatedText: string
}

export function TextGenerator({ onTextGenerated, generatedText }: TextGeneratorProps) {
  const [prompt, setPrompt] = useState("")
  const [genre, setGenre] = useState("fantasy")
  const [length, setLength] = useState("short")
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerate = async () => {
    setIsGenerating(true)

    // Simulate IBM Granite API call
    setTimeout(() => {
      const sampleText = `Chapter 1: The Beginning

In the mystical realm of Eldoria, where ancient magic flows through crystalline rivers and whispers through enchanted forests, a young apprentice named Aria discovered her extraordinary gift. The morning sun cast golden rays through her chamber window, illuminating the leather-bound tome that would change her destiny forever.

As she opened the ancient book, the pages began to glow with an ethereal light. Words appeared as if written by an invisible hand, revealing secrets that had been hidden for centuries. The magic within her stirred, responding to the call of the ancient texts.

"The time has come," whispered a voice that seemed to emanate from the very walls of her tower room. "Your journey begins now, young one. The fate of all realms rests in your hands."

Aria felt a surge of power coursing through her veins, and she knew that her life as a simple apprentice was over. Adventure awaited, and with it, the chance to discover the true extent of her magical abilities.

Chapter 2: The Quest Begins

The cobblestone streets of the village below bustled with activity as Aria made her way to the town square. Merchants hawked their wares, children played in the fountain, and the aroma of fresh bread wafted from the bakery. But Aria's mind was elsewhere, focused on the mysterious message she had received.

At the center of the square stood an ancient oak tree, its branches reaching toward the sky like gnarled fingers. Carved into its trunk were symbols that seemed to pulse with magical energy. As Aria approached, the symbols began to glow, and she felt the familiar tingle of magic in the air.

"You have come," said a figure emerging from behind the tree. It was Master Theron, the village's most respected wizard, his long beard flowing in the gentle breeze. "I have been waiting for you, Aria. The prophecy speaks of one who will unite the scattered realms and restore balance to the world."

Aria's heart raced as she listened to his words. Could she really be the one mentioned in the ancient prophecies? The weight of responsibility settled on her shoulders like a heavy cloak, but she knew she could not turn away from her destiny.`

      onTextGenerated(sampleText)
      setIsGenerating(false)
    }, 3000)
  }

  const handleEnhance = async () => {
    setIsGenerating(true)

    // Simulate text enhancement
    setTimeout(() => {
      const enhancedText =
        generatedText +
        `\n\nChapter 3: The Magical Discovery

The enhanced narrative continued with even greater depth and detail. Aria's magical abilities began to manifest in ways she had never imagined. The ancient tome revealed more secrets, each page turning of its own accord as if guided by an unseen force.

Through the mystical connection with IBM Granite's advanced language processing, the story evolved with sophisticated plot development, rich character descriptions, and immersive world-building that would captivate any audiobook listener.

The AI-powered enhancement ensured that every sentence flowed naturally, creating the perfect foundation for voice synthesis and audio production.`

      onTextGenerated(enhancedText)
      setIsGenerating(false)
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Wand2 className="h-5 w-5 text-purple-400" />
            <span>IBM Granite Text Generation</span>
          </CardTitle>
          <CardDescription className="text-gray-300">
            Generate compelling stories and content using IBM's advanced language model
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="genre" className="text-white">
                Genre
              </Label>
              <Select value={genre} onValueChange={setGenre}>
                <SelectTrigger className="bg-black/20 border-white/20 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-white/20">
                  <SelectItem value="fantasy">Fantasy</SelectItem>
                  <SelectItem value="scifi">Science Fiction</SelectItem>
                  <SelectItem value="mystery">Mystery</SelectItem>
                  <SelectItem value="romance">Romance</SelectItem>
                  <SelectItem value="thriller">Thriller</SelectItem>
                  <SelectItem value="historical">Historical Fiction</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="length" className="text-white">
                Length
              </Label>
              <Select value={length} onValueChange={setLength}>
                <SelectTrigger className="bg-black/20 border-white/20 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-white/20">
                  <SelectItem value="short">Short Story (1-2 chapters)</SelectItem>
                  <SelectItem value="medium">Novella (5-10 chapters)</SelectItem>
                  <SelectItem value="long">Full Novel (15+ chapters)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="prompt" className="text-white">
              Story Prompt
            </Label>
            <Textarea
              id="prompt"
              placeholder="Enter your story idea, characters, or theme..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="bg-black/20 border-white/20 text-white placeholder:text-gray-400 min-h-[100px]"
            />
          </div>

          <div className="flex space-x-3">
            <Button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 flex-1"
            >
              {isGenerating ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4 mr-2" />
              )}
              Generate Story
            </Button>
            {generatedText && (
              <Button
                onClick={handleEnhance}
                disabled={isGenerating}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 bg-transparent"
              >
                <Wand2 className="h-4 w-4 mr-2" />
                Enhance
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {generatedText && (
        <Card className="bg-black/40 border-white/10 text-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-green-400" />
              <span>Generated Content</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={generatedText}
              onChange={(e) => onTextGenerated(e.target.value)}
              className="bg-black/20 border-white/20 text-white min-h-[400px] font-mono text-sm"
              placeholder="Your generated story will appear here..."
            />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
