"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, Users, Clock, Heart, Download, Share2, Eye } from "lucide-react"

interface AnalyticsDashboardProps {
  audioTitle: string
  chapters: Array<{ title: string; startTime: number; duration: number }>
}

export function AnalyticsDashboard({ audioTitle, chapters }: AnalyticsDashboardProps) {
  const [analytics, setAnalytics] = useState<any>(null)
  const [timeRange, setTimeRange] = useState<"24h" | "7d" | "30d">("7d")

  useEffect(() => {
    // Simulate loading analytics data
    const loadAnalytics = () => {
      const mockAnalytics = generateMockAnalytics(chapters)
      setAnalytics(mockAnalytics)
    }

    loadAnalytics()
  }, [chapters, timeRange])

  const generateMockAnalytics = (chapters: any[]) => {
    const totalListeners = Math.floor(Math.random() * 1000) + 100
    const totalPlays = Math.floor(totalListeners * 1.5)
    const avgListenTime = Math.floor(Math.random() * 80) + 20 // 20-100%

    return {
      overview: {
        totalListeners,
        totalPlays,
        avgListenTime,
        completionRate: Math.floor(Math.random() * 40) + 60, // 60-100%
        shares: Math.floor(Math.random() * 50) + 10,
        downloads: Math.floor(Math.random() * 200) + 50,
      },
      chapterAnalytics: chapters.map((chapter, index) => ({
        name: chapter.title,
        listeners: Math.floor(totalListeners * (1 - index * 0.1)),
        avgListenTime: Math.floor(Math.random() * 90) + 10,
        skipRate: Math.floor(Math.random() * 30) + 5,
        engagement: Math.floor(Math.random() * 40) + 60,
      })),
      timeSeriesData: Array.from({ length: 7 }, (_, i) => ({
        date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
        listeners: Math.floor(Math.random() * 100) + 20,
        plays: Math.floor(Math.random() * 150) + 30,
      })),
      deviceData: [
        { name: "Mobile", value: 65, color: "#8884d8" },
        { name: "Desktop", value: 25, color: "#82ca9d" },
        { name: "Tablet", value: 10, color: "#ffc658" },
      ],
      geographicData: [
        { country: "United States", listeners: Math.floor(totalListeners * 0.4) },
        { country: "United Kingdom", listeners: Math.floor(totalListeners * 0.2) },
        { country: "Canada", listeners: Math.floor(totalListeners * 0.15) },
        { country: "Australia", listeners: Math.floor(totalListeners * 0.1) },
        { country: "Others", listeners: Math.floor(totalListeners * 0.15) },
      ],
    }
  }

  if (!analytics) {
    return (
      <Card className="bg-black/40 border-white/10 text-white">
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-gray-300">Loading analytics...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-2xl font-bold">{analytics.overview.totalListeners.toLocaleString()}</p>
                <p className="text-xs text-gray-400">Total Listeners</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Eye className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-2xl font-bold">{analytics.overview.totalPlays.toLocaleString()}</p>
                <p className="text-xs text-gray-400">Total Plays</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-2xl font-bold">{analytics.overview.avgListenTime}%</p>
                <p className="text-xs text-gray-400">Avg Listen Time</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-purple-400" />
              <div>
                <p className="text-2xl font-bold">{analytics.overview.completionRate}%</p>
                <p className="text-xs text-gray-400">Completion Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Engagement Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4 text-center">
            <Share2 className="h-8 w-8 text-blue-400 mx-auto mb-2" />
            <p className="text-xl font-bold">{analytics.overview.shares}</p>
            <p className="text-xs text-gray-400">Shares</p>
          </CardContent>
        </Card>

        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4 text-center">
            <Download className="h-8 w-8 text-green-400 mx-auto mb-2" />
            <p className="text-xl font-bold">{analytics.overview.downloads}</p>
            <p className="text-xs text-gray-400">Downloads</p>
          </CardContent>
        </Card>

        <Card className="bg-black/40 border-white/10 text-white">
          <CardContent className="p-4 text-center">
            <Heart className="h-8 w-8 text-red-400 mx-auto mb-2" />
            <p className="text-xl font-bold">{Math.floor(analytics.overview.totalListeners * 0.15)}</p>
            <p className="text-xs text-gray-400">Favorites</p>
          </CardContent>
        </Card>
      </div>

      {/* Chapter Analytics */}
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BarChart className="h-5 w-5 text-blue-400" />
            <span>Chapter Performance</span>
          </CardTitle>
          <CardDescription className="text-gray-300">Listener engagement by chapter</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.chapterAnalytics}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9CA3AF" fontSize={12} />
                <YAxis stroke="#9CA3AF" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1F2937",
                    border: "1px solid #374151",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="listeners" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Chapter Details */}
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {analytics.chapterAnalytics.map((chapter: any, index: number) => (
              <div key={index} className="flex items-center justify-between p-2 bg-black/20 rounded">
                <span className="text-sm font-medium">{chapter.name}</span>
                <div className="flex items-center space-x-4">
                  <Badge variant="secondary" className="text-xs">
                    {chapter.listeners} listeners
                  </Badge>
                  <Badge variant={chapter.skipRate > 20 ? "destructive" : "default"} className="text-xs">
                    {chapter.skipRate}% skip rate
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Time Series Chart */}
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-green-400" />
            <span>Listener Trends</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analytics.timeSeriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
                <YAxis stroke="#9CA3AF" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1F2937",
                    border: "1px solid #374151",
                    borderRadius: "8px",
                  }}
                />
                <Line type="monotone" dataKey="listeners" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="plays" stroke="#3B82F6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Device & Geographic Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Device Distribution */}
        <Card className="bg-black/40 border-white/10 text-white">
          <CardHeader>
            <CardTitle className="text-lg">Device Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={analytics.deviceData}
                    cx="50%"
                    cy="50%"
                    outerRadius={60}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {analytics.deviceData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Geographic Distribution */}
        <Card className="bg-black/40 border-white/10 text-white">
          <CardHeader>
            <CardTitle className="text-lg">Top Countries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analytics.geographicData.map((country: any, index: number) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm">{country.country}</span>
                  <div className="flex items-center space-x-2 flex-1 ml-4">
                    <Progress
                      value={(country.listeners / analytics.overview.totalListeners) * 100}
                      className="flex-1 h-2"
                    />
                    <span className="text-xs text-gray-400 w-12 text-right">{country.listeners}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
