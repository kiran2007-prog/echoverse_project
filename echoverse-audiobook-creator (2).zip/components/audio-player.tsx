"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, SkipBack, SkipForward, Volume2, Download } from "lucide-react"

interface AudioPlayerProps {
  audioUrl: string
  text?: string
}

export function AudioPlayer({ audioUrl, text }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState([0.8])
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)
  const [actualAudioUrl, setActualAudioUrl] = useState<string>("")

  // Generate real audio using Web Speech API
  const generateRealAudio = async (textToSpeak: string) => {
    if (!textToSpeak || !("speechSynthesis" in window)) {
      console.log("Speech synthesis not supported")
      return
    }

    setIsGeneratingAudio(true)

    try {
      // Cancel any ongoing speech
      speechSynthesis.cancel()

      // Wait a bit for cancellation to complete
      await new Promise((resolve) => setTimeout(resolve, 100))

      // Ensure voices are loaded
      let voices = speechSynthesis.getVoices()
      if (voices.length === 0) {
        // Wait for voices to load
        await new Promise((resolve) => {
          const checkVoices = () => {
            voices = speechSynthesis.getVoices()
            if (voices.length > 0) {
              resolve(voices)
            } else {
              setTimeout(checkVoices, 100)
            }
          }
          checkVoices()
        })
      }

      // Limit text length to prevent errors
      const maxLength = 500
      const truncatedText = textToSpeak.length > maxLength ? textToSpeak.substring(0, maxLength) + "..." : textToSpeak

      const utterance = new SpeechSynthesisUtterance(truncatedText)

      // Find a suitable voice
      const femaleVoice = voices.find(
        (voice) =>
          voice.name.toLowerCase().includes("female") ||
          voice.name.toLowerCase().includes("samantha") ||
          voice.name.toLowerCase().includes("karen") ||
          voice.name.toLowerCase().includes("zira") ||
          (voice.gender && voice.gender === "female"),
      )

      const defaultVoice = voices.find((voice) => voice.default) || voices[0]

      utterance.voice = femaleVoice || defaultVoice || null

      // Set safe parameters
      utterance.rate = Math.max(0.1, Math.min(2.0, 0.9))
      utterance.pitch = Math.max(0.1, Math.min(2.0, 1.0))
      utterance.volume = Math.max(0.1, Math.min(1.0, volume[0]))
      utterance.lang = "en-US"

      utterance.onstart = () => {
        console.log("Speech started")
        setIsPlaying(true)
        setCurrentTime(0)
        // Estimate duration more accurately
        const wordsPerMinute = 150
        const words = truncatedText.split(" ").length
        setDuration(Math.ceil((words / wordsPerMinute) * 60))
      }

      utterance.onend = () => {
        console.log("Speech ended")
        setIsPlaying(false)
        setIsGeneratingAudio(false)
        setCurrentTime(0)
      }

      utterance.onerror = (event) => {
        console.error("Speech synthesis error:", event.error || "Unknown error")
        setIsPlaying(false)
        setIsGeneratingAudio(false)

        // Show user-friendly error message
        alert(`Audio playback failed: ${event.error || "Please try again with shorter text"}`)
      }

      utterance.onpause = () => {
        console.log("Speech paused")
        setIsPlaying(false)
      }

      utterance.onresume = () => {
        console.log("Speech resumed")
        setIsPlaying(true)
      }

      // Start speaking
      console.log("Starting speech synthesis...")
      speechSynthesis.speak(utterance)

      // Update progress with more accurate timing
      const progressInterval = setInterval(() => {
        if (speechSynthesis.speaking && !speechSynthesis.paused) {
          setCurrentTime((prev) => {
            const newTime = prev + 1
            if (newTime >= duration) {
              clearInterval(progressInterval)
              return duration
            }
            return newTime
          })
        } else if (!speechSynthesis.speaking) {
          clearInterval(progressInterval)
        }
      }, 1000)

      // Cleanup interval after maximum expected duration
      setTimeout(
        () => {
          clearInterval(progressInterval)
        },
        duration * 1000 + 5000,
      )
    } catch (error) {
      console.error("Error generating audio:", error)
      setIsGeneratingAudio(false)
      setIsPlaying(false)
      alert("Audio generation failed. Please try again.")
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handlePlayPause = () => {
    if (text && !actualAudioUrl) {
      // Generate and play speech synthesis
      if (isPlaying || speechSynthesis.speaking) {
        console.log("Stopping speech...")
        speechSynthesis.cancel()
        setIsPlaying(false)
        setCurrentTime(0)
      } else {
        console.log("Starting speech...")
        generateRealAudio(text)
      }
    } else if (audioRef.current) {
      // Use regular audio element
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
    }
  }

  const handleSeek = (value: number[]) => {
    const newTime = value[0]
    setCurrentTime(newTime)
    if (audioRef.current) {
      audioRef.current.currentTime = newTime
    }
  }

  const handleVolumeChange = (value: number[]) => {
    setVolume(value)
    if (audioRef.current) {
      audioRef.current.volume = value[0]
    }
  }

  const skipTime = (seconds: number) => {
    if (speechSynthesis.speaking) {
      // For speech synthesis, we'll stop and restart from a different position
      speechSynthesis.cancel()
      setIsPlaying(false)

      if (text && seconds > 0) {
        // Skip ahead by removing words from the beginning
        const words = text.split(" ")
        const wordsPerSecond = 2.5
        const skipWords = Math.floor(Math.abs(seconds) * wordsPerSecond)
        const newText = words.slice(skipWords).join(" ")

        if (newText.length > 10) {
          setTimeout(() => {
            generateRealAudio(newText)
          }, 200)
        }
      }
    } else if (audioRef.current) {
      const newTime = Math.max(0, Math.min(duration, currentTime + seconds))
      audioRef.current.currentTime = newTime
      setCurrentTime(newTime)
    }
  }

  // Load voices when component mounts
  useEffect(() => {
    const loadVoices = () => {
      speechSynthesis.getVoices()
    }

    loadVoices()
    if (speechSynthesis.onvoiceschanged !== undefined) {
      speechSynthesis.onvoiceschanged = loadVoices
    }
  }, [])

  return (
    <Card className="bg-black/40 border-white/10 text-white">
      <CardHeader>
        <CardTitle className="text-lg">Audio Preview</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Hidden audio element for future file playback */}
        {actualAudioUrl && (
          <audio
            ref={audioRef}
            src={actualAudioUrl}
            onLoadedMetadata={() => {
              if (audioRef.current) {
                setDuration(audioRef.current.duration)
              }
            }}
            onTimeUpdate={() => {
              if (audioRef.current) {
                setCurrentTime(audioRef.current.currentTime)
              }
            }}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
          />
        )}

        {/* Waveform Visualization */}
        <div className="h-20 bg-gradient-to-r from-purple-900/50 to-blue-900/50 rounded-lg flex items-center justify-center border border-white/10">
          <div className="flex items-end space-x-1 h-12">
            {Array.from({ length: 40 }).map((_, i) => (
              <div
                key={i}
                className={`w-1 bg-gradient-to-t from-purple-500 to-blue-500 rounded-full transition-all duration-300 ${
                  isPlaying ? "animate-pulse" : ""
                }`}
                style={{
                  height: `${Math.random() * 100}%`,
                  opacity: duration > 0 && i < (currentTime / duration) * 40 ? 1 : 0.3,
                }}
              />
            ))}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <Slider value={[currentTime]} onValueChange={handleSeek} max={duration || 100} step={1} className="w-full" />
          <div className="flex justify-between text-sm text-gray-400">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Status */}
        {isGeneratingAudio && <div className="text-center text-sm text-yellow-400">🎤 Generating speech...</div>}

        {text && <div className="text-center text-sm text-green-400">✨ Ready to play with AI voice synthesis</div>}

        {/* Controls */}
        <div className="flex items-center justify-center space-x-4">
          <Button
            size="sm"
            variant="ghost"
            className="text-white hover:bg-white/10"
            onClick={() => skipTime(-15)}
            disabled={isGeneratingAudio}
          >
            <SkipBack className="h-4 w-4" />
          </Button>

          <Button
            size="lg"
            onClick={handlePlayPause}
            disabled={isGeneratingAudio || (!text && !actualAudioUrl)}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-full w-12 h-12"
          >
            {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
          </Button>

          <Button
            size="sm"
            variant="ghost"
            className="text-white hover:bg-white/10"
            onClick={() => skipTime(15)}
            disabled={isGeneratingAudio}
          >
            <SkipForward className="h-4 w-4" />
          </Button>
        </div>

        {/* Volume Control */}
        <div className="flex items-center space-x-3">
          <Volume2 className="h-4 w-4 text-gray-400" />
          <Slider value={volume} onValueChange={handleVolumeChange} max={1} step={0.1} className="flex-1" />
          <span className="text-sm text-gray-400 w-10">{Math.round(volume[0] * 100)}%</span>
        </div>

        {/* Instructions */}
        <div className="p-3 bg-blue-500/20 rounded-lg border border-blue-500/30">
          <p className="text-sm text-blue-300">
            💡 <strong>How to hear audio:</strong>
          </p>
          <ul className="text-xs text-gray-300 mt-1 space-y-1">
            <li>1. Generate text in the "Generate" tab</li>
            <li>2. Come back here and click the play button</li>
            <li>3. Your browser will speak the text using AI voice</li>
          </ul>
        </div>

        {/* Download Button */}
        <Button
          variant="outline"
          className="w-full border-white/20 text-white hover:bg-white/10 bg-transparent"
          disabled={!text}
        >
          <Download className="h-4 w-4 mr-2" />
          Export Audio (Coming Soon)
        </Button>
      </CardContent>
    </Card>
  )
}
