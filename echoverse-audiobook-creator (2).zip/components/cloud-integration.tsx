"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Upload, Share2, ExternalLink, CheckCircle, Clock, Youtube, Music, Headphones, HardDrive } from "lucide-react"

interface CloudIntegrationProps {
  audioUrl: string
  title: string
  metadata: {
    duration: number
    fileSize: number
    chapters: Array<{ title: string; startTime: number }>
  }
}

const platforms = [
  {
    id: "spotify",
    name: "Spotify Podcasts",
    icon: Music,
    description: "Upload as podcast episode",
    color: "bg-green-500",
    requirements: ["RSS feed", "Podcast hosting"],
  },
  {
    id: "audible",
    name: "Audible ACX",
    icon: Headphones,
    description: "Submit to Audible marketplace",
    color: "bg-orange-500",
    requirements: ["ACX account", "Quality standards"],
  },
  {
    id: "youtube",
    name: "YouTube",
    icon: Youtube,
    description: "Upload as video with waveform",
    color: "bg-red-500",
    requirements: ["YouTube account", "Video format"],
  },
  {
    id: "gdrive",
    name: "Google Drive",
    icon: HardDrive,
    description: "Save to cloud storage",
    color: "bg-blue-500",
    requirements: ["Google account", "Drive access"],
  },
]

export function CloudIntegration({ audioUrl, title, metadata }: CloudIntegrationProps) {
  const [uploadStatus, setUploadStatus] = useState<Record<string, "idle" | "uploading" | "success" | "error">>({})
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({})
  const [shareableLinks, setShareableLinks] = useState<Record<string, string>>({})

  const handleUpload = async (platformId: string) => {
    setUploadStatus((prev) => ({ ...prev, [platformId]: "uploading" }))
    setUploadProgress((prev) => ({ ...prev, [platformId]: 0 }))

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        const currentProgress = prev[platformId] || 0
        if (currentProgress >= 100) {
          clearInterval(progressInterval)
          return prev
        }
        return { ...prev, [platformId]: currentProgress + 10 }
      })
    }, 500)

    try {
      // Simulate API call to platform
      await simulateUpload(platformId, title, audioUrl, metadata)

      // Generate shareable link
      const shareableLink = generateShareableLink(platformId, title)
      setShareableLinks((prev) => ({ ...prev, [platformId]: shareableLink }))

      setUploadStatus((prev) => ({ ...prev, [platformId]: "success" }))
    } catch (error) {
      setUploadStatus((prev) => ({ ...prev, [platformId]: "error" }))
    }

    clearInterval(progressInterval)
  }

  const simulateUpload = async (platform: string, title: string, audioUrl: string, metadata: any) => {
    // Simulate different upload times for different platforms
    const uploadTimes = {
      spotify: 3000,
      audible: 5000,
      youtube: 4000,
      gdrive: 2000,
    }

    await new Promise((resolve) => setTimeout(resolve, uploadTimes[platform as keyof typeof uploadTimes] || 3000))

    // Simulate potential errors
    if (Math.random() < 0.1) {
      // 10% chance of error
      throw new Error(`Upload to ${platform} failed`)
    }
  }

  const generateShareableLink = (platform: string, title: string) => {
    const baseUrls = {
      spotify: "https://open.spotify.com/episode/",
      audible: "https://www.audible.com/pd/",
      youtube: "https://youtube.com/watch?v=",
      gdrive: "https://drive.google.com/file/d/",
    }

    const randomId = Math.random().toString(36).substring(2, 15)
    return `${baseUrls[platform as keyof typeof baseUrls]}${randomId}`
  }

  const copyToClipboard = (link: string) => {
    navigator.clipboard.writeText(link)
    // You could add a toast notification here
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/40 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Upload className="h-5 w-5 text-blue-400" />
            <span>Cloud Integration & Sharing</span>
          </CardTitle>
          <CardDescription className="text-gray-300">
            Export your audiobook to popular platforms and generate shareable links
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {platforms.map((platform) => {
              const Icon = platform.icon
              const status = uploadStatus[platform.id] || "idle"
              const progress = uploadProgress[platform.id] || 0
              const shareLink = shareableLinks[platform.id]

              return (
                <Card key={platform.id} className="bg-black/20 border-white/10">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className={`p-2 ${platform.color} rounded-lg`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-white">{platform.name}</h4>
                        <p className="text-xs text-gray-400">{platform.description}</p>
                      </div>
                      <Badge
                        variant={status === "success" ? "default" : status === "error" ? "destructive" : "secondary"}
                        className="text-xs"
                      >
                        {status === "idle" && "Ready"}
                        {status === "uploading" && "Uploading"}
                        {status === "success" && "Success"}
                        {status === "error" && "Error"}
                      </Badge>
                    </div>

                    {status === "uploading" && (
                      <div className="mb-3">
                        <Progress value={progress} className="h-2" />
                        <p className="text-xs text-gray-400 mt-1">{progress}% uploaded</p>
                      </div>
                    )}

                    {shareLink && (
                      <div className="mb-3 p-2 bg-green-500/20 rounded border border-green-500/30">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-green-300 truncate">{shareLink}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(shareLink)}
                            className="text-green-400 hover:text-green-300 h-6 px-2"
                          >
                            Copy
                          </Button>
                        </div>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Button
                        onClick={() => handleUpload(platform.id)}
                        disabled={status === "uploading" || !audioUrl}
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                        size="sm"
                      >
                        {status === "uploading" ? (
                          <>
                            <Clock className="h-4 w-4 mr-2" />
                            Uploading...
                          </>
                        ) : status === "success" ? (
                          <>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Uploaded
                          </>
                        ) : (
                          <>
                            <Upload className="h-4 w-4 mr-2" />
                            Upload to {platform.name}
                          </>
                        )}
                      </Button>

                      {shareLink && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full border-white/20 text-white hover:bg-white/10 bg-transparent"
                          onClick={() => window.open(shareLink, "_blank")}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Open Link
                        </Button>
                      )}
                    </div>

                    <div className="mt-3 pt-3 border-t border-white/10">
                      <p className="text-xs text-gray-400 mb-1">Requirements:</p>
                      <ul className="text-xs text-gray-500 space-y-1">
                        {platform.requirements.map((req, index) => (
                          <li key={index}>• {req}</li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Shareable Links Summary */}
      {Object.keys(shareableLinks).length > 0 && (
        <Card className="bg-green-500/20 border-green-500/30 text-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Share2 className="h-5 w-5 text-green-400" />
              <span>Shareable Links</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {Object.entries(shareableLinks).map(([platform, link]) => (
                <div key={platform} className="flex items-center justify-between p-2 bg-black/20 rounded">
                  <span className="text-sm font-medium capitalize">{platform}:</span>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-300 truncate max-w-48">{link}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(link)}
                      className="text-green-400 hover:text-green-300 h-6 px-2"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
