-- EchoVerse Database Setup
-- Creates tables for managing audiobook projects, users, and audio files

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    genre VARCHAR(50),
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'processing', 'completed', 'failed')),
    word_count INTEGER DEFAULT 0,
    estimated_duration INTEGER DEFAULT 0, -- in seconds
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Text content table
CREATE TABLE IF NOT EXISTS text_content (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    chapter_number INTEGER,
    chapter_title VARCHAR(200),
    word_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Voice configurations table
CREATE TABLE IF NOT EXISTS voice_configs (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    voice_id VARCHAR(50) NOT NULL,
    voice_name VARCHAR(100),
    speed DECIMAL(3,2) DEFAULT 1.00,
    pitch DECIMAL(3,2) DEFAULT 1.00,
    volume DECIMAL(3,2) DEFAULT 0.80,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Audio files table
CREATE TABLE IF NOT EXISTS audio_files (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    file_path VARCHAR(500) NOT NULL,
    file_name VARCHAR(200) NOT NULL,
    file_size BIGINT,
    duration INTEGER, -- in seconds
    format VARCHAR(10) DEFAULT 'mp3',
    quality VARCHAR(20) DEFAULT 'high',
    status VARCHAR(20) DEFAULT 'processing' CHECK (status IN ('processing', 'completed', 'failed')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chapter markers table
CREATE TABLE IF NOT EXISTS chapter_markers (
    id SERIAL PRIMARY KEY,
    audio_file_id INTEGER REFERENCES audio_files(id) ON DELETE CASCADE,
    chapter_number INTEGER NOT NULL,
    chapter_title VARCHAR(200),
    start_time INTEGER NOT NULL, -- in seconds
    end_time INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Processing logs table
CREATE TABLE IF NOT EXISTS processing_logs (
    id SERIAL PRIMARY KEY,
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    step VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('started', 'completed', 'failed')),
    message TEXT,
    processing_time INTEGER, -- in milliseconds
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_text_content_project_id ON text_content(project_id);
CREATE INDEX IF NOT EXISTS idx_audio_files_project_id ON audio_files(project_id);
CREATE INDEX IF NOT EXISTS idx_chapter_markers_audio_file_id ON chapter_markers(audio_file_id);
CREATE INDEX IF NOT EXISTS idx_processing_logs_project_id ON processing_logs(project_id);

-- Insert sample data for demonstration
INSERT INTO users (username, email) VALUES 
('demo_user', 'demo@echoverse.ai'),
('test_creator', 'creator@echoverse.ai')
ON CONFLICT (username) DO NOTHING;

INSERT INTO projects (user_id, title, description, genre, status, word_count, estimated_duration) VALUES 
(1, 'The Enchanted Forest', 'A magical adventure story about a young wizard discovering ancient secrets', 'fantasy', 'completed', 2500, 1080),
(1, 'Mystery of the Lost City', 'An archaeological thriller set in the Amazon rainforest', 'mystery', 'processing', 1800, 720),
(2, 'Space Adventure Chronicles', 'Epic space opera spanning multiple galaxies', 'scifi', 'draft', 950, 380)
ON CONFLICT DO NOTHING;

-- Sample text content
INSERT INTO text_content (project_id, content, chapter_number, chapter_title, word_count) VALUES 
(1, 'Chapter 1: The Beginning. In the mystical realm of Eldoria, where ancient magic flows through crystalline rivers...', 1, 'The Beginning', 450),
(1, 'Chapter 2: The Discovery. As she opened the ancient book, the pages began to glow with an ethereal light...', 2, 'The Discovery', 380)
ON CONFLICT DO NOTHING;

-- Sample voice configurations
INSERT INTO voice_configs (project_id, voice_id, voice_name, speed, pitch, volume) VALUES 
(1, 'neural-voice-1', 'Emma', 1.00, 1.00, 0.80),
(2, 'neural-voice-2', 'James', 0.95, 1.05, 0.75)
ON CONFLICT DO NOTHING;

-- Sample audio files
INSERT INTO audio_files (project_id, file_path, file_name, file_size, duration, format, status) VALUES 
(1, '/audio/enchanted_forest_complete.mp3', 'The Enchanted Forest - Complete', 15728640, 1080, 'mp3', 'completed')
ON CONFLICT DO NOTHING;

-- Sample chapter markers
INSERT INTO chapter_markers (audio_file_id, chapter_number, chapter_title, start_time, end_time) VALUES 
(1, 1, 'The Beginning', 0, 540),
(1, 2, 'The Discovery', 540, 1080)
ON CONFLICT DO NOTHING;

COMMIT;
