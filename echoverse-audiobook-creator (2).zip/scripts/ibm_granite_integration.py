"""
IBM Granite Model Integration for EchoVerse
This script demonstrates how to integrate IBM Granite for text generation
"""

import requests
import json
import os
from typing import Dict, List, Optional

class IBMGraniteClient:
    def __init__(self, api_key: str, endpoint: str):
        """
        Initialize IBM Granite client
        
        Args:
            api_key: Your IBM Cloud API key
            endpoint: IBM Granite model endpoint
        """
        self.api_key = api_key
        self.endpoint = endpoint
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
    
    def generate_story(self, prompt: str, genre: str = "fantasy", 
                      max_tokens: int = 2000, temperature: float = 0.7) -> Dict:
        """
        Generate story content using IBM Granite
        
        Args:
            prompt: Story prompt or idea
            genre: Story genre (fantasy, scifi, mystery, etc.)
            max_tokens: Maximum tokens to generate
            temperature: Creativity level (0.0-1.0)
            
        Returns:
            Generated story content
        """
        
        # Enhanced prompt with genre-specific instructions
        enhanced_prompt = f"""
        Genre: {genre.title()}
        
        Create an engaging story based on the following prompt. Include:
        - Rich character development
        - Vivid descriptions suitable for audio narration
        - Clear chapter breaks
        - Engaging dialogue
        - Immersive world-building
        
        Prompt: {prompt}
        
        Story:
        """
        
        payload = {
            "model_id": "ibm/granite-13b-chat-v2",
            "input": enhanced_prompt,
            "parameters": {
                "max_new_tokens": max_tokens,
                "temperature": temperature,
                "top_p": 0.9,
                "repetition_penalty": 1.1
            }
        }
        
        try:
            response = requests.post(
                f"{self.endpoint}/v1/text/generation",
                headers=self.headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "text": result.get("results", [{}])[0].get("generated_text", ""),
                    "token_count": result.get("results", [{}])[0].get("token_count", 0)
                }
            else:
                return {
                    "success": False,
                    "error": f"API Error: {response.status_code}",
                    "message": response.text
                }
                
        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "error": "Connection Error",
                "message": str(e)
            }
    
    def enhance_text(self, text: str, enhancement_type: str = "narrative") -> Dict:
        """
        Enhance existing text for better audiobook quality
        
        Args:
            text: Original text to enhance
            enhancement_type: Type of enhancement (narrative, dialogue, description)
            
        Returns:
            Enhanced text
        """
        
        enhancement_prompts = {
            "narrative": "Enhance this text for audiobook narration by improving flow, adding descriptive details, and ensuring smooth transitions:",
            "dialogue": "Improve the dialogue in this text to make it more natural and engaging for audio listeners:",
            "description": "Enhance the descriptive elements in this text to create more vivid imagery for audiobook listeners:"
        }
        
        prompt = f"{enhancement_prompts.get(enhancement_type, enhancement_prompts['narrative'])}\n\n{text}\n\nEnhanced version:"
        
        return self.generate_story(prompt, max_tokens=len(text.split()) * 2)
    
    def create_chapter_structure(self, text: str) -> List[Dict]:
        """
        Analyze text and suggest chapter breaks
        
        Args:
            text: Full text to analyze
            
        Returns:
            List of chapter information
        """
        
        prompt = f"""
        Analyze the following text and suggest appropriate chapter breaks. 
        For each chapter, provide:
        1. Chapter title
        2. Starting position (approximate word count)
        3. Brief summary
        
        Text to analyze:
        {text[:1000]}...
        
        Chapter structure:
        """
        
        result = self.generate_story(prompt, max_tokens=500, temperature=0.3)
        
        # Parse the result to extract chapter information
        # This would need more sophisticated parsing in a real implementation
        chapters = []
        if result.get("success"):
            # Simple parsing - in production, use more robust text processing
            lines = result["text"].split('\n')
            for i, line in enumerate(lines):
                if line.strip().startswith(('Chapter', 'chapter')):
                    chapters.append({
                        "title": line.strip(),
                        "position": i * 100,  # Approximate
                        "summary": lines[i+1] if i+1 < len(lines) else ""
                    })
        
        return chapters

def main():
    """
    Example usage of IBM Granite integration
    """
    
    # Initialize client (you would get these from environment variables)
    api_key = os.getenv("IBM_GRANITE_API_KEY", "your-api-key-here")
    endpoint = os.getenv("IBM_GRANITE_ENDPOINT", "https://your-granite-endpoint.com")
    
    client = IBMGraniteClient(api_key, endpoint)
    
    # Example story generation
    prompt = "A young wizard discovers an ancient library that contains books from parallel universes"
    genre = "fantasy"
    
    print("Generating story with IBM Granite...")
    result = client.generate_story(prompt, genre)
    
    if result["success"]:
        print(f"Generated {result['token_count']} tokens")
        print("\nGenerated Story:")
        print("-" * 50)
        print(result["text"])
        
        # Enhance the generated text
        print("\nEnhancing text for audiobook...")
        enhanced = client.enhance_text(result["text"], "narrative")
        
        if enhanced["success"]:
            print("\nEnhanced Version:")
            print("-" * 50)
            print(enhanced["text"])
            
            # Create chapter structure
            chapters = client.create_chapter_structure(enhanced["text"])
            print(f"\nSuggested Chapters: {len(chapters)}")
            for chapter in chapters:
                print(f"- {chapter['title']}: {chapter['summary']}")
    else:
        print(f"Error: {result['error']}")
        print(f"Message: {result['message']}")

if __name__ == "__main__":
    main()
